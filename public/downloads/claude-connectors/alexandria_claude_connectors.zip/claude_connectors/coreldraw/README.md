# coreldraw-live, as Alexandria ships it

The MCP server that lets Claude work in the document open in CorelDRAW, through CorelDRAW's own automation (COM) on the same PC. `../install.ps1` copies this folder to `%USERPROFILE%\.alexandria\claude_connectors\coreldraw`, gives it its own Python and adds it to Claude as `coreldraw-live`.

It is **CorelDRAW Live MCP 0.2.2** by 深圳市玄熵智能科技有限责任公司 (Xuanshang Intelligent Technology Co., Ltd., Shenzhen), under the Apache License 2.0: see `LICENSE` and `NOTICE`. Taken from https://github.com/CubicDev1/corel-mcp at its only upstream commit (`235affb`, 2026-08-01). That repo has had no commit since, and its earlier home, https://github.com/wuguirongsg/coreldraw-mcp, stops at 0.1.0, so Alexandria carries its own copy rather than installing from either.

## What Alexandria changed

As the license asks (section 4b), the changes to the upstream files:

- `server/core/connection.py`, `server/core/sessions.py` (2026-11-19): attaching to a running CorelDRAW. A private `gen_py` cache, raw `pythoncom` binding with late-bound dispatch, versioned ProgIDs, attaching through the class factory when CorelDRAW isn't in the Running Object Table, real HRESULTs in the errors, and a bounded document fingerprint so an attach can't hang. Never launches a second CorelDRAW.
- `server/server.py` (2026-11-19): the server attaches to CorelDRAW in the background at start, instead of holding the MCP handshake until CorelDRAW answers. A CorelDRAW with a dialog open took a minute, and Claude gave up on the server.

Left out, because the connector doesn't use them: the bundled chat agent and its Streamlit app (`server/agent/`, `server/app.py`), the HTTPS wrapper (`server/server_https.py`), the tests and the docs. What is here makes no network connection: it talks to Claude over stdin and stdout, and to CorelDRAW over COM.

## Files

| | |
|---|---|
| `server/server.py` | The entry point. Claude runs it with `--transport stdio` |
| `server/core/` | The connection to CorelDRAW, document sessions, coordinates and the edit operations |
| `server/tools/live.py` | The 14 tools Claude gets (`COREL_TOOL_PROFILE=compact`): status, attach, inspect, apply operations, preview, undo and redo, save, export |
| `server/tools/*.py` (the rest) | Upstream's older 70-tool catalog, off unless `COREL_TOOL_PROFILE=legacy`. Its data merge tools need packages that aren't installed |
| `requirements.txt` | Every Python package, pinned to a version and a hash, for Python 3.12 on 64-bit Windows |

## Updating the packages

`requirements.txt` is written by uv from the six packages the server names. To move to newer versions, put the versions wanted in a `requirements.in` and run:

```
uv pip compile requirements.in --python-version 3.12 --python-platform x86_64-pc-windows-msvc --generate-hashes --no-header -o requirements.txt
```

Then run `..\install.ps1` and try the server in CorelDRAW before releasing. The installer rebuilds a PC's Python when this file changes.
