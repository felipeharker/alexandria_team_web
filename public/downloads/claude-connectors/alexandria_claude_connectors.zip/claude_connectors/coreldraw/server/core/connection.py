import os
import re
import sys
import queue
import threading
import time
import logging
from typing import Optional, Callable, Any
from dataclasses import dataclass

if sys.platform == "win32":
    # Private, empty makepy cache. pywin32's default gen_py cache (%TEMP%\gen_py\<ver>) is shared by every Python
    # process on the machine and filled on demand by whichever one touches a type library; concurrent writers (e.g.
    # several MCP server instances) left the CorelDRAW package there half-written (no __init__.py), and from then on
    # every win32com.client.Dispatch of a CorelDRAW object raised AttributeError ... 'CLSIDToClassMap' - which this
    # server misreported as "close any open dialog". Pointing gencache at a directory nothing generates into makes
    # every CorelDRAW object late-bound (IDispatch), independent of that cache. Must run before win32com.client loads.
    import win32com

    _GEN_PATH = os.environ.get("COREL_GENPY_DIR") or os.path.join(
        os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "corel-mcp", "gen_py")
    os.makedirs(_GEN_PATH, exist_ok=True)
    win32com.__gen_path__ = _GEN_PATH
    win32com.gen_py.__path__ = [_GEN_PATH]

    import win32com.client
    import win32com.client.dynamic
    from win32com.client import gencache as _gencache
    import pythoncom
    import pywintypes

    # In case win32com.client was imported (and loaded the shared cache's index) before this module.
    for _name in [n for n in sys.modules if n.startswith("win32com.gen_py.")]:
        del sys.modules[_name]
    _gencache.clsidToTypelib.clear()
    _gencache.versionRedirectMap.clear()
    _gencache.__init__()


# HRESULTs a busy CorelDRAW (modal dialog, long operation) answers with. Only these are worth a retry and only
# these justify telling the user to close a dialog.
_BUSY_HRESULTS = {
    0x80010001: "RPC_E_CALL_REJECTED",
    0x8001010A: "RPC_E_SERVERCALL_RETRYLATER",
    0x80080005: "CO_E_SERVER_EXEC_FAILURE",
}


def _describe_error(exc: Exception) -> str:
    """The real failure, with its HRESULT when it is a COM error, so it is never misreported."""
    if sys.platform == "win32" and isinstance(exc, pywintypes.com_error):
        code = exc.hresult & 0xFFFFFFFF
        name = _BUSY_HRESULTS.get(code)
        return "HRESULT 0x%08X%s %s" % (code, " (%s)" % name if name else "", exc.strerror)
    return "%s: %s" % (type(exc).__name__, exc)


def _is_busy(exc: Exception) -> bool:
    return (sys.platform == "win32" and isinstance(exc, pywintypes.com_error)
            and (exc.hresult & 0xFFFFFFFF) in _BUSY_HRESULTS)


def _late_bound(unknown) -> Any:
    """Wrap a raw COM pointer with pure late binding. win32com.client.Dispatch/GetActiveObject consult the shared
    makepy cache (%TEMP%\\gen_py); a half-written CorelDRAW package there (missing __init__.py) makes them raise
    AttributeError even though COM itself connected. win32com.client.dynamic never touches that cache, and the
    objects it returns are wrapped the same way, so the whole object tree is immune to it."""
    return win32com.client.dynamic.Dispatch(unknown.QueryInterface(pythoncom.IID_IDispatch))


def _corel_processes() -> list:
    """(process id, executable path) of every running CorelDRAW. Must run on a COM-initialised thread."""
    try:
        wmi = win32com.client.GetObject("winmgmts:")
        rows = wmi.ExecQuery("SELECT ProcessId, ExecutablePath FROM Win32_Process WHERE Name = 'CorelDRW.exe'")
        return [(int(row.ProcessId), str(row.ExecutablePath or "")) for row in rows]
    except Exception:
        logging.getLogger(__name__).warning("could not list CorelDRAW processes", exc_info=True)
        return []


def _prog_ids(app_name: str, processes: list) -> list:
    """The ProgIDs to try: the versioned one of each running CorelDRAW (...\\Graphics Suite\\26\\Programs64\\ ->
    CorelDRAW.Application.26) first - with several versions installed the version-independent ProgID can point at
    another one - then the configured name."""
    ids = []
    for _pid, path in processes:
        match = re.search(r"\\(\d+)\\Programs64\\", path, re.IGNORECASE)
        if match:
            ids.append("CorelDRAW.Application.%s" % match.group(1))
    ids.append(app_name)
    return list(dict.fromkeys(ids))


@dataclass
class ConnectionConfig:
    max_retries: int = 3
    retry_delay: float = 1.0
    app_name: str = os.environ.get("COREL_CORELDRAW_APP_NAME", "CorelDRAW.Application")
    visible: bool = True
    reconnect_on_failure: bool = False
    # existing_only is the safe default for live editing.  It prevents a
    # temporary ROT/COM lookup failure from silently launching a second copy of
    # CorelDRAW.  Use attach_or_launch only for unattended generation workers.
    attach_policy: str = os.environ.get("COREL_ATTACH_POLICY", "existing_only")


@dataclass
class ConnectionStatus:
    connected: bool = False
    app_running: bool = False
    version: Optional[str] = None
    last_error: Optional[str] = None


class _COMTask:
    __slots__ = ("func", "args", "kwargs", "result", "error", "_done")

    def __init__(self, func: Callable, args: tuple, kwargs: dict):
        self.func = func
        self.args = args
        self.kwargs = kwargs
        self.result: Any = None
        self.error: Optional[Exception] = None
        self._done = threading.Event()

    def wait(self, timeout: float) -> Any:
        if not self._done.wait(timeout=timeout):
            logging.getLogger(__name__).warning(
                "COM call timed out after %.1fs; the STA task may still be finishing",
                timeout,
            )
            raise TimeoutError(f"COM call timed out after {timeout}s")
        if self.error is not None:
            raise self.error
        return self.result


class _COMThread(threading.Thread):
    """Dedicated STA thread that owns all CorelDRAW COM objects.

    FastMCP HTTP mode dispatches sync tool functions via run_in_executor to a
    thread pool. COM STA objects cannot be called across thread boundaries
    (RPC_E_WRONG_THREAD). This thread serialises every COM operation so the
    calling thread's apartment never matters.
    """

    def __init__(self):
        super().__init__(daemon=True, name="COM-STA-Thread")
        self._queue: "queue.Queue[Optional[_COMTask]]" = queue.Queue()
        self._ready = threading.Event()
        self._running = True

    def run(self) -> None:
        if sys.platform == "win32":
            pythoncom.CoInitialize()
        self._ready.set()
        try:
            while True:
                task = self._queue.get()
                if task is None:
                    break
                try:
                    task.result = task.func(*task.args, **task.kwargs)
                except Exception as exc:
                    task.error = exc
                finally:
                    task._done.set()
        finally:
            if sys.platform == "win32":
                try:
                    pythoncom.CoUninitialize()
                except Exception:
                    pass

    def call(self, func: Callable, *args, timeout: float = 60.0, **kwargs) -> Any:
        if not self._running:
            raise RuntimeError("COM thread has been shut down")
        # Public tools may be composed into a higher-level transaction.  When
        # that transaction is already running on this STA, queueing and waiting
        # on the same thread would deadlock.  Execute re-entrant calls directly.
        if threading.current_thread() is self:
            return func(*args, **kwargs)
        task = _COMTask(func, args, kwargs)
        self._queue.put(task)
        return task.wait(timeout)

    def shutdown(self) -> None:
        self._running = False
        self._queue.put(None)


class CorelDrawConnection:
    def __init__(self, config: Optional[ConnectionConfig] = None):
        self.config = config or ConnectionConfig()
        self._app = None
        self._status = ConnectionStatus()
        self._com_thread = _COMThread()
        self._com_thread.start()
        self._com_thread._ready.wait()

    @property
    def app(self):
        return self._app

    @property
    def status(self) -> ConnectionStatus:
        return self._status

    def connect(self, allow_launch: bool = True) -> bool:
        # allow_launch=False never starts CorelDRAW, whatever COREL_ATTACH_POLICY says. Server startup,
        # status checks, attaching to open documents and reconnect retries all pass False, so CorelDRAW is
        # only launched by a tool that explicitly needs a new document (see SessionManager.create_new).
        if sys.platform != "win32":
            self._status.last_error = "Platform not supported"
            return False

        def _do_connect():
            log = logging.getLogger(__name__)
            processes = _corel_processes()
            prog_ids = _prog_ids(self.config.app_name, processes)
            errors = []
            # 1. The Running Object Table. (Raw pythoncom calls + late binding: see _late_bound.)
            for prog_id in prog_ids:
                try:
                    return _late_bound(pythoncom.GetActiveObject(pywintypes.IID(prog_id)))
                except Exception as exc:
                    errors.append("GetActiveObject(%s): %s" % (prog_id, _describe_error(exc)))
            # 2. A running CorelDRAW that isn't in the ROT. CorelDRAW 2026 started by opening a .cdr registers its
            # class factory but often not its ROT entry (only the document's file moniker), so GetActiveObject
            # fails with MK_E_UNAVAILABLE while it's open. CoCreateInstance reaches that running process's class
            # factory instead of launching one - checked: if a new process appears anyway it is quit and the
            # attach fails, never a second copy. A busy CorelDRAW (RPC_E_CALL_REJECTED etc.) is retried briefly.
            if processes:
                before = set(pid for pid, _path in processes)
                for prog_id in prog_ids:
                    unknown = None
                    for attempt in range(5):
                        try:
                            unknown = pythoncom.CoCreateInstance(
                                prog_id, None, pythoncom.CLSCTX_LOCAL_SERVER, pythoncom.IID_IDispatch)
                            break
                        except Exception as exc:
                            if _is_busy(exc) and attempt < 4:
                                time.sleep(1.0)
                                continue
                            errors.append("CoCreateInstance(%s): %s" % (prog_id, _describe_error(exc)))
                            break
                    if unknown is None:
                        continue
                    try:
                        app = _late_bound(unknown)
                    except Exception as exc:
                        errors.append("wrap(%s): %s" % (prog_id, _describe_error(exc)))
                        continue
                    started = set(pid for pid, _path in _corel_processes()) - before
                    if not started:
                        log.info("Attached to the running CorelDRAW through %s (not in the ROT)", prog_id)
                        return app
                    try:
                        app.Quit()
                    except Exception:
                        pass
                    raise RuntimeError(
                        "CorelDRAW is running but answered %s by starting another copy (closed again); "
                        "restart CorelDRAW and try again." % prog_id
                    )
                detail = "; ".join(errors)
                log.warning("Could not attach to the running CorelDRAW: %s", detail)
                busy = any(name in detail for name in _BUSY_HRESULTS.values())
                raise RuntimeError(
                    "CorelDRAW is running but refused an automation connection (%s).%s" % (
                        detail,
                        " CorelDRAW reports it is busy: close any open dialog in CorelDRAW and try again."
                        if busy else "",
                    )
                )
            # 3. No CorelDRAW running.
            if self.config.attach_policy == "existing_only" or not allow_launch:
                raise RuntimeError(
                    "No running CorelDRAW instance was found. Start CorelDRAW "
                    "first or set COREL_ATTACH_POLICY=attach_or_launch."
                )
            app = _late_bound(pythoncom.CoCreateInstance(
                self.config.app_name, None, pythoncom.CLSCTX_LOCAL_SERVER, pythoncom.IID_IDispatch))
            app.Visible = self.config.visible
            return app

        try:
            self._app = self._com_thread.call(_do_connect)
            version = self._com_thread.call(lambda: self._app.Version)
            self._status = ConnectionStatus(connected=True, app_running=True, version=version)
            return True
        except Exception as e:
            self._status = ConnectionStatus(connected=False, app_running=False, last_error=str(e))
            return False

    def disconnect(self) -> None:
        # Release COM reference without calling Quit() — user owns CorelDRAW lifecycle.
        self._app = None
        self._status = ConnectionStatus()
        self._com_thread.shutdown()

    def reconnect(self) -> bool:
        self._app = None
        self._status = ConnectionStatus()
        # Replace the COM thread so the new connection gets a fresh STA.
        self._com_thread.shutdown()
        self._com_thread = _COMThread()
        self._com_thread.start()
        self._com_thread._ready.wait()
        time.sleep(self.config.retry_delay)
        # A retry must not relaunch a CorelDRAW the user just closed.
        return self.connect(allow_launch=False)

    def is_alive(self) -> bool:
        if not self._app or not self._status.connected:
            return False
        try:
            # ActiveDocument raises in the perfectly healthy zero-document
            # state. Version and Documents.Count are safe health probes.
            self._com_thread.call(
                lambda: (self._app.Version, self._app.Documents.Count),
                timeout=5.0,
            )
            return True
        except Exception:
            return False

    def safe_call(
        self,
        func,
        *args,
        timeout: float = 60.0,
        idempotent: bool = True,
        **kwargs,
    ):
        last_error = None
        attempts = self.config.max_retries if idempotent else 1
        for attempt in range(attempts):
            try:
                result = self._com_thread.call(func, *args, timeout=timeout, **kwargs)
                return {"success": True, "result": result}
            except Exception as e:
                last_error = str(e)
                # A timed-out task may still commit later, so it must never be
                # replayed—even when the caller marked it idempotent.
                if isinstance(e, TimeoutError):
                    break
                if attempt < attempts - 1 and self.config.reconnect_on_failure:
                    if not self.reconnect():
                        break
        return {"success": False, "result": None, "error": last_error or "Unknown error"}


_connection: Optional[CorelDrawConnection] = None


def get_connection() -> CorelDrawConnection:
    global _connection
    if _connection is None:
        _connection = CorelDrawConnection()
    return _connection


def init_connection(config: Optional[ConnectionConfig] = None, allow_launch: bool = False) -> bool:
    # Called at MCP server startup: attach to a running CorelDRAW only, never launch one.
    global _connection
    _connection = CorelDrawConnection(config)
    return _connection.connect(allow_launch=allow_launch)


def close_connection() -> None:
    global _connection
    if _connection:
        _connection.disconnect()
        _connection = None
