"""squarecoil: an MCP server (stdio) that gives Claude Aria's SquareCoil design request lists.

    python server.py

Claude starts it; it isn't for running by hand. Python standard library only: it speaks MCP's
JSON-RPC over stdin and stdout itself, one message per line, and logs to stderr. The work is
done by squarecoil.py beside it, which also has the command line and the login.
"""
from __future__ import annotations

import json
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import squarecoil  # noqa: E402

SERVER_INFO = {"name": "squarecoil", "version": "1.0.0"}
PROTOCOL_VERSIONS = ("2025-06-18", "2025-03-26", "2024-11-05")
CACHE_SECONDS = 60

TOOLS = [
    {
        "name": "list_design_requests",
        "title": "List SquareCoil design requests",
        "description": (
            "Aria's design requests from SquareCoil, live from its dashboard (the Design Requests view). "
            "Each has section (In Progress, Next Job or On Hold), design_id (like 260574-01), description "
            "(client and job), created_by, type (Presentation, Production, Pre-Production, Revision, Permits "
            "Required, Const. Dwgs.), date (requested), due_date, assigned_to, overdue (SquareCoil shows the "
            "due date in red), flagged (SquareCoil's red warning triangle), design_key (for "
            "get_design_request) and url. Dates are YYYY-MM-DD. Every filter is optional and they combine."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "section": {"type": "string", "description": "In Progress (the default), Next Job, On Hold, or all."},
                "assigned_to": {"type": "string", "description": "Part of the designer's name, any case."},
                "search": {"type": "string", "description": "Text to find in the design id, description, people or type."},
                "overdue_only": {"type": "boolean", "description": "Only those SquareCoil marks overdue."},
                "due_by": {"type": "string", "description": "Only those due on or before this date, YYYY-MM-DD."},
                "limit": {"type": "integer", "description": "Most rows to return (default 200)."},
            },
            "additionalProperties": False,
        },
        "annotations": {"readOnlyHint": True, "openWorldHint": True},
    },
    {
        "name": "get_design_request",
        "title": "Get one SquareCoil design request",
        "description": (
            "The details of one design request: the text of the pop-up its info icon opens on the SquareCoil "
            "dashboard (project and design notes). Takes design_key from list_design_requests, not the design_id."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {"design_key": {"type": "string", "description": "SquareCoil's number for the design, like 6126."}},
            "required": ["design_key"],
            "additionalProperties": False,
        },
        "annotations": {"readOnlyHint": True, "openWorldHint": True},
    },
]


class Server:
    def __init__(self) -> None:
        self.sc = squarecoil.SquareCoil()
        self._rows: list[dict] = []
        self._fetched = 0.0

    def rows(self) -> tuple[list[dict], float]:
        if time.time() - self._fetched > CACHE_SECONDS:
            self._rows = self.sc.design_requests()
            self._fetched = time.time()
        return self._rows, self._fetched

    def list_design_requests(self, section: str = "In Progress", assigned_to: str = "", search: str = "",
                             overdue_only: bool = False, due_by: str = "", limit: int = 200) -> dict:
        rows, fetched = self.rows()
        section = "" if section.strip().lower() == "all" else section
        found = squarecoil.filter_designs(rows, section=section, assigned_to=assigned_to, search=search,
                                          overdue_only=overdue_only, due_by=due_by)
        return {
            "fetched_at": datetime.fromtimestamp(fetched).isoformat(timespec="seconds"),
            "matching": len(found),
            "returned": min(len(found), limit),
            "total_on_dashboard": len(rows),
            "design_requests": found[:max(0, limit)],
        }

    def get_design_request(self, design_key: str) -> dict:
        return {"design_key": design_key, "details": self.sc.design_details(design_key)}

    def call(self, name: str, arguments: dict) -> dict:
        try:
            if name == "list_design_requests":
                result = self.list_design_requests(**arguments)
            elif name == "get_design_request":
                result = self.get_design_request(**arguments)
            else:
                return {"content": [{"type": "text", "text": f"Unknown tool: {name}"}], "isError": True}
            return {"content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}], "isError": False}
        except (squarecoil.SquareCoilError, TypeError) as e:
            return {"content": [{"type": "text", "text": str(e)}], "isError": True}

    def handle(self, msg: dict) -> dict | None:
        method, mid = msg.get("method"), msg.get("id")
        if mid is None:  # a notification: nothing to answer
            return None
        params = msg.get("params") or {}
        if method == "initialize":
            asked = params.get("protocolVersion")
            result = {
                "protocolVersion": asked if asked in PROTOCOL_VERSIONS else PROTOCOL_VERSIONS[0],
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": SERVER_INFO,
                "instructions": "Read-only access to Aria's SquareCoil design request lists. Start with list_design_requests.",
            }
        elif method == "ping":
            result = {}
        elif method == "tools/list":
            result = {"tools": TOOLS}
        elif method == "tools/call":
            result = self.call(params.get("name", ""), params.get("arguments") or {})
        else:
            return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": f"Method not found: {method}"}}
        return {"jsonrpc": "2.0", "id": mid, "result": result}


def main() -> None:
    server = Server()
    out = sys.stdout.buffer
    for line in sys.stdin.buffer:
        if not line.strip():
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            reply = {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}}
        else:
            try:
                reply = server.handle(msg)
            except Exception as e:  # keep serving; say what broke
                traceback.print_exc(file=sys.stderr)
                reply = {"jsonrpc": "2.0", "id": msg.get("id"), "error": {"code": -32603, "message": str(e)}}
        if reply is not None:
            out.write(json.dumps(reply, ensure_ascii=False).encode("utf-8") + b"\n")
            out.flush()


if __name__ == "__main__":
    main()
