@echo off
rem Starts the SquareCoil MCP server (stdio) with the Python the installer gave this folder.
rem Alexandria's squarecoil plugin, in Claude and Grok, starts it this way, since a command set up once
rem for the whole team can't name a user's folder:
rem   command  cmd
rem   args     /c  cd  /d  %USERPROFILE%  &&  .alexandria\claude_connectors\squarecoil\squarecoil-mcp.cmd
rem (cd /d first, because it is the one way a user folder with a space in its name gets through unquoted)
if not exist "%~dp0.venv\Scripts\python.exe" (
  echo squarecoil: not installed on this PC. Run Install Connectors on Rhino's Alexandria Tools tab, or Install Claude Connectors.cmd. 1>&2
  exit /b 1
)
"%~dp0.venv\Scripts\python.exe" -I "%~dp0server.py" %*
