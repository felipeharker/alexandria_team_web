@echo off
rem Starts the SquareCoil MCP server (stdio) with the Python the installer gave this folder.
rem For an MCP client set up once for the whole team, whose command can't name a user's folder:
rem   command  cmd
rem   args     /c  cd  /d  %USERPROFILE%  &&  .alexandria\claude_connectors\squarecoil\squarecoil-mcp.cmd
rem (cd /d first, because it is the one way a user folder with a space in its name gets through unquoted)
rem Claude doesn't use this: the installer points it at python.exe and server.py themselves.
if not exist "%~dp0.venv\Scripts\python.exe" (
  echo squarecoil: not installed on this PC. Run Install Connectors on Rhino's Alexandria Tools tab, or Install Claude Connectors.cmd. 1>&2
  exit /b 1
)
"%~dp0.venv\Scripts\python.exe" -I "%~dp0server.py" %*
