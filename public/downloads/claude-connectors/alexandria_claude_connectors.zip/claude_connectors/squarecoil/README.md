# squarecoil

Gives Claude Aria's design request lists from SquareCoil, the sign-shop system at `ariasigns.squarecoil.net`, live. SquareCoil has no API, MCP server or Zapier app, so this signs in through its login form and reads the lists the way a browser would: `dashboard.php?show=2` is an empty shell whose script posts to `dashboard_designs.php` (`action=1`) and drops the lists in, so the connector posts there itself, with no browser. Read-only: it never changes anything in SquareCoil. Python standard library only.

## Tools

| Tool | What it gives |
|---|---|
| `list_design_requests` | The design requests on the dashboard, filtered by `section` (In Progress by default, Next Job, On Hold or all), `assigned_to`, `search`, `overdue_only` and `due_by` |
| `get_design_request` | One request's details, the text of the pop-up its info icon opens, by `design_key` |

Each design request comes back as:

```json
{
 "section": "In Progress", "design_id": "260574-01", "description": "Client, job",
 "created_by": "…", "type": ["Presentation"], "date": "2026-09-15",
 "due_date": "2026-11-26", "assigned_to": "…", "overdue": false, "flagged": false,
 "design_key": "6126", "project_number": "260574",
 "url": "https://ariasigns.squarecoil.net/project_designs.php?designid=6126&id=260574"
}
```

`overdue` is SquareCoil's red due date, and `flagged` its red warning triangle. `design_key` and `project_number` are SquareCoil's own numbers, from the row's link.

## On a PC

The connectors' installer (`../install.ps1`, run by Alexandria Setup and Install Connectors in Rhino, or `Install Claude Connectors.cmd`) copies this folder to `%USERPROFILE%\.alexandria\claude_connectors\squarecoil`, gives it a Python of its own, and adds `squarecoil` to Claude Desktop and Claude Code.

Everyone signs in with their own SquareCoil login, once. The installer runs `squarecoil.py login` in its window: it checks the username and password against SquareCoil and only then keeps them in Windows Credential Manager as `alexandria/squarecoil/ariasigns`, never in a file. Claude then sees what that login sees. An empty username skips it. To change the login, run `python squarecoil.py login` again; to remove it, delete `alexandria/squarecoil/ariasigns` in Credential Manager (Windows Credentials, Generic), or uninstall the connectors.

## Files

| File | What it is |
|---|---|
| `squarecoil.py` | Signing in, reading the lists and the details pop-up, the login in Credential Manager, and a command line: `login`, `designs [--json] [--section] [--assigned-to] [--overdue]`, `design KEY`, `parse FILE` |
| `server.py` | The MCP server Claude runs, over stdin and stdout. MCP's JSON-RPC done by hand, one message per line |

The tests and the saved dashboard page they run against hold real client names, so they stay in the private `alexandria_management` repo, in `agent_connectors/squarecoil/`, and never ship here: the hub's zip of this folder is public.

## When SquareCoil changes

The login is a plain form (`login.php`, fields `action=1`, `username`, `password`). The lists come from a POST to `dashboard_designs.php` (`action=1`, `multiple_location_id` empty). They are `div.design-list-container` blocks with the ids `inProgress`, `nextJob` and `onHold`, one `div.row` per request with eight column divs. If SquareCoil changes them, the tools say so instead of returning nothing. Then save the page again over the private fixture, fix the parser in `squarecoil.py` and the numbers in the tests.

If SquareCoil ever offers an API or a scheduled export, switch `SquareCoil.design_requests` to it and keep the tools as they are.
