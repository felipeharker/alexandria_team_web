# squarecoil

Gives Claude, or any other MCP client, Aria's SquareCoil, the sign-shop system at `ariasigns.squarecoil.net`, live: the design request lists, every project and what it holds, the customers, and the files. SquareCoil has no API, MCP server or Zapier app, so this signs in through its login form and reads the pages a browser would, with no browser. Each person signs in with their own SquareCoil login and sees what that login sees. Python standard library only.

It is read-only. SquareCoil changes things on a plain link (`project_designs.php?…&action=2` deletes a design), so `squarecoil.py` keeps a list of the pages it reads, `READ_PAGES`, with the fields each may send, and refuses anything else before it reaches the network. SquareCoil's own activity log does record each project tab that gets opened, under the person's name, the same as when they open it in a browser.

## Tools

| Tool | What it gives |
|---|---|
| `list_design_requests` | The design requests on the dashboard, filtered by `section` (In Progress by default, Next Job, On Hold or all), `assigned_to`, `search`, `overdue_only` and `due_by` |
| `get_design_request` | One request's details, the text of the pop-up its info icon opens, by `design_key` |
| `search_projects` | Projects, newest first, 25 to a page. `query` tries a number as a project number and anything else against name, site address, billing name, description and city. Or fields that combine: `number`, `name`, `address`, `city`, `state`, `description`, `billing_name`, `purchase_order`, `salesperson`, `project_manager`, `status` |
| `get_project` | One project by `project_number`: name, status, site address, open date, salesperson, project manager, project and site contacts, the customer it bills to, important notes and scope of work. `include` adds its tabs: `designs`, `status`, `tasks`, `documents`, `photos`, `production_files`, `contacts`, `activity`, `costs`, or `all` |
| `search_customers` | The customer records whose name, address or sales rep has the text |
| `download_file` | Saves one file to the PC, in `Downloads\SquareCoil\<project number>` unless given a `folder`, and says where. Takes a file's `url` from `get_project` |

What `include` adds to a project:

| Part | From SquareCoil's tab | What comes back |
|---|---|---|
| `designs` | Design | Every design request: number, type, assigned to, due date, priority, created by, status, hours, files, and the description with its revisions |
| `status` | Project Status | Each milestone (Landlord Approval, Permits, Survey, Manufacturing, Shipping, Install, Service, Invoice Notes) with its dates and its notes, each note with who wrote it and when |
| `tasks` | Tasks | Every task with its subject, dates, people and message |
| `documents`, `photos`, `production_files` | Documents, Photos, Production Files | Each file's name, its `url` for `download_file`, and what its row says (who, size, type, date) |
| `contacts` | Contacts | The contacts added to the project |
| `activity` | Activity Log | What changed and when, without the tab views unless `activity_views` is on, and `emails_sent` |
| `costs` | Cost To Date | The lines that have a figure, estimated and actual |

A design request from `list_design_requests` carries `project_number`, which is what `get_project` takes.

## On a PC

The connectors' installer (`../install.ps1`, run by Alexandria Setup and Install Connectors in Rhino, or `Install Claude Connectors.cmd`) copies this folder to `%USERPROFILE%\.alexandria\claude_connectors\squarecoil` and gives it a Python of its own. Alexandria's `squarecoil` plugin, which the team's organization has in Claude and in Grok, starts it from there with `squarecoil-mcp.cmd`.

Everyone signs in with their own SquareCoil login, once. The installer runs `squarecoil.py login` in its window: it checks the username and password against SquareCoil and only then keeps them in Windows Credential Manager as `alexandria/squarecoil/ariasigns`, never in a file. To change the login, run `python squarecoil.py login` again; to remove it, delete `alexandria/squarecoil/ariasigns` in Credential Manager (Windows Credentials, Generic), or uninstall the connectors.

## Claude, Grok and other MCP clients

The server speaks standard MCP, so every client runs the same installed copy on the person's own PC, with the same stored login. Claude and Grok get it from Alexandria's `squarecoil` plugin (the public [`alexandria_plugins`](https://github.com/felipeharker/alexandria_plugins) repository), which the team's organization in each already has. Each person still runs the connectors' installer once, which is what puts the server and their login on the PC. Another client (Cursor, anything that takes an `mcp.json`) has two ways in, and which one depends on what the client's Transport offers.

Added for a whole team, as the plugin is, a server can't name anybody's user folder, so it starts `squarecoil-mcp.cmd`, which finds its own Python:

| Field | Value |
|---|---|
| Name | `squarecoil` |
| Transport | Command |
| Command | `cmd` |
| Arguments, one each, in this order | `/c` `cd` `/d` `%USERPROFILE%` `&&` `.alexandria\claude_connectors\squarecoil\squarecoil-mcp.cmd` |
| Environment variables | none |

It doesn't belong in a list of servers for cloud agents (Grok's Team mcp.json): an agent in the cloud has neither the server nor anybody's login.

One person's own client that starts a command can take this instead, with their user folder in the paths:

```json
{
  "mcpServers": {
    "squarecoil": {
      "command": "C:\\Users\\NAME\\.alexandria\\claude_connectors\\squarecoil\\.venv\\Scripts\\python.exe",
      "args": ["-I", "C:\\Users\\NAME\\.alexandria\\claude_connectors\\squarecoil\\server.py"]
    }
  }
}
```

A client that takes a URL (HTTP) needs the server running on the PC first:

```powershell
python server.py --http
```

Then the URL is `http://127.0.0.1:8765/mcp` (`--port` changes the port), with no sign-in, header or OAuth client: the server listens on that PC only, answers that PC only, and uses the login stored there. The URL works only for a client that runs on the person's PC. A client that calls MCP servers from its own cloud can't reach `127.0.0.1`, and hosting this for the whole team would mean keeping everybody's SquareCoil password on a server, which it doesn't do.

## Files

| File | What it is |
|---|---|
| `squarecoil.py` | Signing in, the list of pages it may read, the design request lists, the login in Credential Manager, and a command line: `login`, `designs`, `design KEY`, `parse FILE`, `search`, `project NUMBER --include …`, `customers`, `download URL` |
| `projects.py` | Reading the project search, a project's tabs, the customers and the files. Each parser takes a page's text and nothing else |
| `server.py` | The MCP server, over stdin and stdout or over HTTP with `--http`. MCP's JSON-RPC done by hand |
| `squarecoil-mcp.cmd` | Starts `server.py` with the folder's own Python, for a client whose command is shared by a team |

The tests and the saved pages they run against hold real client names, so they stay in the private `alexandria_management` repo, in `agent_connectors/squarecoil/`, beside this folder's own home there, and never ship with it: the hub's zip of this folder is public.

## When SquareCoil changes

The login is a plain form (`login.php`, fields `action=1`, `username`, `password`). Where each thing comes from:

| What | Request | Read by |
|---|---|---|
| Design request lists | POST `dashboard_designs.php` (`action=1`): `div.design-list-container` blocks `inProgress`, `nextJob`, `onHold`, one `div.row` each | `squarecoil.parse_dashboard` |
| Project search | POST `search.php` (`action=1` and the form's fields); later pages from the pager's own link, `projects.php?action=2&page=N`. SquareCoil's pages overlap, each 25 further on and up to 100 rows, so only the first 25 of each are used | `projects.parse_search` |
| Overview | `project.php?id=N` | `parse_overview` |
| Billing customer | `edit_project_customer.php?id=N`, opened and never saved | `parse_billing` |
| Designs | `project_designs.php?id=N`, then `&designid=K` for each | `parse_design_list`, `parse_design` |
| Milestones and notes | `project_milestones.php?id=N`, one `#tab-K` pane each | `parse_status` |
| Tasks | `project_tasks.php?id=N`, then `&taskid=K` for each | `parse_task_list`, `parse_task` |
| Files | `project_documents.php`, `project_site_photos.php`, `project_production_files.php`; a file is a link to `download_*.php` or to a file's own address | `parse_files` |
| Activity | `project_activity_logs.php?id=N`, and `&email=1` | `parse_log` |
| Customers | POST `jq.customers.php`, which answers in JSON | `projects.customers` |

If SquareCoil changes a page, the tool says so or comes back empty for that part. Run `save_fixtures.py` in the private repo to save the pages again, fix the parser and the values in the tests. A new page to read goes in `READ_PAGES` first.

Aria had no site photos, production files or design files in SquareCoil on 2026-11-25, so those three are read by the general rule for files and haven't met a real one yet.

If SquareCoil ever offers an API or a scheduled export, switch to it and keep the tools as they are.
