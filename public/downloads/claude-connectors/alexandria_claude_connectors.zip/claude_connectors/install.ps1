<#
Alexandria: the Claude connectors (MCP servers) for Rhino, CorelDRAW and SquareCoil, on this Windows PC.

    powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1 [-Only rhino,coreldraw,squarecoil]
                                                                    [-Check] [-Status] [-Uninstall] [-NoPause]

Alexandria Setup and Install Connectors in Rhino run this, and so does "Install Claude Connectors.cmd"
beside it. Run it again at any time: it only does what is still missing, and updates what it installed.

Rhino      McNeel's own Rhino-MCP-Platform package, installed into Rhino 8 with Rhino's package
           manager (Yak) from McNeel's server. A small launcher, rhino-mcp.cmd, starts whichever
           version of it is installed, so the connector survives the package's updates.
CorelDRAW  The coreldraw-live server in coreldraw/ beside this script, copied to this PC with
           its own Python (uv installs both, and the pinned packages in requirements.txt).
           Only on a PC that has CorelDRAW.
SquareCoil The squarecoil server in squarecoil/ beside this script (Python standard library only),
           copied to this PC with its own Python from uv. It reads Aria's design requests and projects with
           the person's own SquareCoil login, which it asks for once, checks against SquareCoil and
           keeps in Windows Credential Manager. Leaving the username empty skips it, and -Check
           stops asking; Install Connectors in Rhino (-AskLogin) asks again.
Claude     Each is added to Claude Desktop's config and to Claude Code's, whichever are here.
           Nothing else in those files is touched: a config is backed up, our entries are
           put in place in its text, and the result is checked before it replaces the file. An
           entry of the same name that somebody else set up is left as it is.

Everything this installs lives in %USERPROFILE%\.alexandria\claude_connectors (not AppData: the Claude Desktop
app from the Microsoft Store sees its own private copy of AppData).

-Only       Just these connectors, by key: rhino, coreldraw, squarecoil (comma-separated). All by default.
-Check      Changes nothing. Exit code 0 when there is nothing to do, 1 when there is.
-Status     Changes nothing. One line per connector, key<TAB>state<TAB>what: state is ok, todo,
            absent (its program isn't on this PC), skipped or failed. Install Connectors reads it.
-AskLogin   Asks for the SquareCoil login even after it was skipped.
-Uninstall  Takes the entries this added out of the Claude configs, the SquareCoil login out of
            Credential Manager, and deletes the folder. The Rhino package stays: uninstall it in
            Rhino's Package Manager.
-NoPause    Doesn't wait for a key at the end.
The rest are for testing: -InstallHome, -DesktopConfig, -SkipDesktop, -SkipClaudeCode, -Source.

Keep this file ASCII: Windows PowerShell 5.1 reads a script without a BOM as ANSI.
#>
[CmdletBinding()]
param(
    [string[]]$Only,
    [switch]$Check,
    [switch]$Status,
    [switch]$AskLogin,
    [switch]$Uninstall,
    [switch]$NoPause,
    [string]$InstallHome,
    [string[]]$DesktopConfig,
    [switch]$SkipDesktop,
    [switch]$SkipClaudeCode,
    [string]$Source
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2

$RHINO_NAME = 'rhino-mcp-platform'
$COREL_NAME = 'coreldraw-live'
$SQUARECOIL_NAME = 'squarecoil'
$SQUARECOIL_TARGET = 'alexandria/squarecoil/ariasigns'   # its login in Windows Credential Manager, as squarecoil.py names it
$LOGIN_SKIPPED = 3                                         # squarecoil.py login's exit code when the username is left empty
$RHINO_PACKAGE = 'Rhino-MCP-Platform'
$PYTHON_VERSION = '3.12'

if ($Status) { $Check = $true }   # -Status is -Check, told per connector
if (-not $InstallHome) { $InstallHome = $env:ALEXANDRIA_CONNECTORS_HOME }
if (-not $InstallHome) { $InstallHome = Join-Path $env:USERPROFILE '.alexandria\claude_connectors' }
$InstallHome = [IO.Path]::GetFullPath($InstallHome)
if (-not $Source) { $Source = $PSScriptRoot }
$LogFile = Join-Path $InstallHome 'install.log'

$script:Pending = New-Object System.Collections.ArrayList   # what -Check found to do
$script:Failed = New-Object System.Collections.ArrayList
$script:Changed = $false
$script:Note = $null       # why a connector was left out: set by Install-* with NoteKind absent, skipped or failed
$script:NoteKind = $null

Add-Type -AssemblyName System.Web.Extensions
$script:Json = New-Object System.Web.Script.Serialization.JavaScriptSerializer
$script:Json.MaxJsonLength = [int]::MaxValue
$script:Json.RecursionLimit = 500


# ------------------------------------------------------------------ output
function Log([string]$text) {
    if ($Check -or $Uninstall) { return }
    try {
        if (-not (Test-Path $InstallHome)) { New-Item -ItemType Directory -Force $InstallHome | Out-Null }
        Add-Content -LiteralPath $LogFile -Value ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $text) -Encoding UTF8
    } catch { }
}

function Say([string]$text) {
    if (-not $Check) { Write-Host $text }
    Log $text
}

function Need([string]$what) {
    # In -Check, notes that something is still to do. Returns $true when the caller should do it now.
    if ($Check) { [void]$script:Pending.Add($what); return $false }
    return $true
}

function Fail([string]$what) {
    [void]$script:Failed.Add($what)
    Say ("  ! " + $what)
}

function Quote-Arg([string]$arg) {
    if ($arg -match '[\s"]') { return '"' + $arg + '"' }
    return $arg
}

function Run-Tool([string]$exe, [string[]]$arguments, [hashtable]$environment) {
    # Runs a program without a window of its own, its output going to the log. Returns its exit code.
    $out = [IO.Path]::GetTempFileName()
    $err = [IO.Path]::GetTempFileName()
    $saved = @{}
    try {
        if ($environment) {
            foreach ($key in $environment.Keys) {
                $saved[$key] = [Environment]::GetEnvironmentVariable($key, 'Process')
                [Environment]::SetEnvironmentVariable($key, $environment[$key], 'Process')
            }
        }
        Log ("run: " + $exe + " " + ($arguments -join ' '))
        $line = ($arguments | ForEach-Object { Quote-Arg $_ }) -join ' '
        $process = Start-Process -FilePath $exe -ArgumentList $line -NoNewWindow -Wait -PassThru `
            -RedirectStandardOutput $out -RedirectStandardError $err
        foreach ($file in $out, $err) {
            $text = [IO.File]::ReadAllText($file).Trim()
            if ($text) { Log $text }
        }
        return $process.ExitCode
    } finally {
        foreach ($key in $saved.Keys) { [Environment]::SetEnvironmentVariable($key, $saved[$key], 'Process') }
        Remove-Item -LiteralPath $out, $err -ErrorAction SilentlyContinue
    }
}

function Get-Utf8Bytes([string]$text, [bool]$bom) {
    $body = (New-Object System.Text.UTF8Encoding($false)).GetBytes($text)
    if (-not $bom) { return ,$body }
    $bytes = New-Object byte[] ($body.Length + 3)
    $bytes[0] = 0xEF; $bytes[1] = 0xBB; $bytes[2] = 0xBF
    [Array]::Copy($body, 0, $bytes, 3, $body.Length)
    return ,$bytes
}

function Write-Atomic([string]$path, [byte[]]$bytes) {
    $temp = $path + '.alexandria-new'
    [IO.File]::WriteAllBytes($temp, $bytes)
    if (Test-Path -LiteralPath $path) {
        try { [IO.File]::Replace($temp, $path, $null) }
        catch { Copy-Item -LiteralPath $temp -Destination $path -Force; Remove-Item -LiteralPath $temp -Force }
    } else {
        Move-Item -LiteralPath $temp -Destination $path
    }
}


# ------------------------------------------------------------------ JSON, read in place
# A config is never parsed and written back whole: that would reorder or reformat what other
# programs keep in it. These find where a member sits in the text, so only that part changes.
function Skip-Ws([string]$t, [int]$i) {
    while ($i -lt $t.Length -and " `t`r`n".IndexOf($t[$i]) -ge 0) { $i++ }
    return $i
}

function Skip-String([string]$t, [int]$i) {
    # $t[$i] is the opening quote. Returns the index after the closing one.
    $from = $i + 1
    while ($true) {
        $quote = $t.IndexOf('"', $from)
        if ($quote -lt 0) { throw 'a string never ends' }
        $slashes = 0
        $k = $quote - 1
        while ($k -ge $from -and $t[$k] -eq '\') { $slashes++; $k-- }
        if ($slashes % 2 -eq 0) { return $quote + 1 }
        $from = $quote + 1
    }
}

function Skip-Value([string]$t, [int]$i) {
    # Returns the index after the value that starts at $i.
    $c = $t[$i]
    if ($c -eq '"') { return (Skip-String $t $i) }
    if ($c -eq '{' -or $c -eq '[') {
        $marks = '"{}[]'.ToCharArray()
        $depth = 0
        while ($true) {
            $i = $t.IndexOfAny($marks, $i)
            if ($i -lt 0) { throw 'an object never ends' }
            $c = $t[$i]
            if ($c -eq '"') { $i = Skip-String $t $i; continue }
            if ($c -eq '{' -or $c -eq '[') { $depth++ } else { $depth--; if ($depth -eq 0) { return $i + 1 } }
            $i++
        }
    }
    while ($i -lt $t.Length -and ",}] `t`r`n".IndexOf($t[$i]) -lt 0) { $i++ }
    return $i
}

function Get-Members([string]$t, [int]$open) {
    # The members of the object whose "{" is at $open, in order, each with where its key and value sit.
    $members = New-Object System.Collections.ArrayList
    $i = Skip-Ws $t ($open + 1)
    while ($t[$i] -ne '}') {
        if ($t[$i] -ne '"') { throw "expected a name at character $i" }
        $keyStart = $i
        $i = Skip-String $t $i
        $name = [string]$script:Json.DeserializeObject($t.Substring($keyStart, $i - $keyStart))
        $i = Skip-Ws $t $i
        if ($t[$i] -ne ':') { throw "expected ':' at character $i" }
        $valueStart = Skip-Ws $t ($i + 1)
        $i = Skip-Value $t $valueStart
        [void]$members.Add((New-Object psobject -Property @{
            Name = $name; KeyStart = $keyStart; ValueStart = $valueStart; ValueEnd = $i }))
        $i = Skip-Ws $t $i
        if ($t[$i] -eq ',') { $i = Skip-Ws $t ($i + 1) }
        elseif ($t[$i] -ne '}') { throw "expected ',' or '}' at character $i" }
    }
    return (New-Object psobject -Property @{ Members = $members; Open = $open; Close = $i })
}

function Find-Member($object, [string]$name) {
    foreach ($member in $object.Members) { if ($member.Name -ceq $name) { return $member } }
    return $null
}

function Get-ServerBlock([string]$t) {
    # The top object and its "mcpServers" object ($null when there is none).
    $open = Skip-Ws $t 0
    if ($open -ge $t.Length -or $t[$open] -ne '{') { throw 'the file is not a JSON object' }
    $top = Get-Members $t $open
    $member = Find-Member $top 'mcpServers'
    $servers = $null
    if ($member) {
        if ($t[$member.ValueStart] -ne '{') { throw '"mcpServers" is not an object' }
        $servers = Get-Members $t $member.ValueStart
    }
    return (New-Object psobject -Property @{ Top = $top; Servers = $servers })
}

function ConvertTo-JsonString([string]$text) {
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('"')
    foreach ($ch in $text.ToCharArray()) {
        $code = [int]$ch
        if ($ch -eq '"') { [void]$sb.Append('\"') }
        elseif ($ch -eq '\') { [void]$sb.Append('\\') }
        elseif ($code -lt 32 -or $code -gt 126) { [void]$sb.Append(('\u{0:x4}' -f $code)) }
        else { [void]$sb.Append($ch) }
    }
    [void]$sb.Append('"')
    return $sb.ToString()
}

function ConvertTo-ServerJson($server, [string]$nl, [string]$indent, [bool]$compact) {
    # A server entry as JSON text: type (Claude Code only), command, args, env, in that order.
    $inner = $indent + '  '
    $parts = New-Object System.Collections.ArrayList
    if ($server.ContainsKey('type')) { [void]$parts.Add('"type": ' + (ConvertTo-JsonString $server['type'])) }
    [void]$parts.Add('"command": ' + (ConvertTo-JsonString $server.command))
    $items = @($server.args | ForEach-Object { ConvertTo-JsonString $_ })
    if ($compact) { [void]$parts.Add('"args": [' + ($items -join ',') + ']') }
    else { [void]$parts.Add('"args": [' + $nl + (($items | ForEach-Object { $inner + '  ' + $_ }) -join (',' + $nl)) + $nl + $inner + ']') }
    if ($server.env.Count) {
        $pairs = @($server.env.Keys | ForEach-Object { (ConvertTo-JsonString $_) + ': ' + (ConvertTo-JsonString $server.env[$_]) })
        if ($compact) { [void]$parts.Add('"env": {' + ($pairs -join ',') + '}') }
        else { [void]$parts.Add('"env": {' + $nl + (($pairs | ForEach-Object { $inner + '  ' + $_ }) -join (',' + $nl)) + $nl + $inner + '}') }
    }
    if ($compact) { return '{' + ($parts -join ',') + '}' }
    return '{' + $nl + (($parts | ForEach-Object { $inner + $_ }) -join (',' + $nl)) + $nl + $indent + '}'
}

function Test-SameServer($existing, $server) {
    # $existing is an entry as read from a config; $server is ours.
    if (-not ($existing -is [System.Collections.IDictionary])) { return $false }
    if (-not $existing.ContainsKey('command') -or [string]$existing['command'] -ne $server.command) { return $false }
    $theirs = @()
    if ($existing.ContainsKey('args') -and $existing['args']) { $theirs = @($existing['args'] | ForEach-Object { [string]$_ }) }
    if (($theirs -join "`n") -cne (@($server.args) -join "`n")) { return $false }
    $settings = @{}
    if ($existing.ContainsKey('env') -and ($existing['env'] -is [System.Collections.IDictionary])) { $settings = $existing['env'] }
    if ($settings.Count -ne $server.env.Count) { return $false }
    foreach ($key in $server.env.Keys) {
        if (-not $settings.ContainsKey($key) -or [string]$settings[$key] -cne $server.env[$key]) { return $false }
    }
    return $true
}

function Test-Ours($existing) {
    # Whether an entry runs something from our folder, so it is ours to update or remove.
    if (-not ($existing -is [System.Collections.IDictionary])) { return $false }
    $words = @()
    if ($existing.ContainsKey('command')) { $words += [string]$existing['command'] }
    if ($existing.ContainsKey('args') -and $existing['args']) { $words += @($existing['args'] | ForEach-Object { [string]$_ }) }
    foreach ($word in $words) {
        if ($word.StartsWith($InstallHome + '\', [StringComparison]::OrdinalIgnoreCase)) { return $true }
    }
    return $false
}

function Read-Text([string]$path) {
    # A config's text, with whether it starts with a BOM.
    $bytes = [IO.File]::ReadAllBytes($path)
    $bom = $bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF
    $text = (New-Object System.Text.UTF8Encoding($false, $true)).GetString($bytes)   # throws on bytes that are not UTF-8
    if ($bom) { $text = $text.Substring(1) }
    return (New-Object psobject -Property @{ Text = $text; Bom = $bom })
}

function Get-Plan([string]$text, $servers) {
    # What each of our servers needs in this config text: 'add', 'update', 'same' or 'foreign'.
    $block = Get-ServerBlock $text
    $plan = [ordered]@{}
    foreach ($name in $servers.Keys) {
        $member = $null
        if ($block.Servers) { $member = Find-Member $block.Servers $name }
        if (-not $member) { $plan[$name] = 'add'; continue }
        $existing = $script:Json.DeserializeObject($text.Substring($member.ValueStart, $member.ValueEnd - $member.ValueStart))
        if (Test-SameServer $existing $servers[$name]) { $plan[$name] = 'same' }
        elseif (Test-Ours $existing) { $plan[$name] = 'update' }
        else { $plan[$name] = 'foreign' }
    }
    return $plan
}

function Set-Servers([string]$text, $servers, $plan) {
    # The config text with our entries added or updated as the plan says. Everything else stays as it was.
    $nl = "`n"
    if ($text.Contains("`r`n")) { $nl = "`r`n" }
    $block = Get-ServerBlock $text
    $adds = @($plan.Keys | Where-Object { $plan[$_] -eq 'add' })
    $edits = New-Object System.Collections.ArrayList   # start, end, replacement
    foreach ($name in @($plan.Keys | Where-Object { $plan[$_] -eq 'update' })) {
        $member = Find-Member $block.Servers $name
        [void]$edits.Add((New-Object psobject -Property @{ Start = $member.ValueStart; End = $member.ValueEnd
            Text = (ConvertTo-ServerJson $servers[$name] $nl '    ' $false) }))
    }
    if ($adds.Count) {
        $entries = @($adds | ForEach-Object { '    ' + (ConvertTo-JsonString $_) + ': ' + (ConvertTo-ServerJson $servers[$_] $nl '    ' $false) })
        $joined = $entries -join (',' + $nl)
        if ($block.Servers) {
            # at the top of the existing "mcpServers"
            $tail = ','
            if ($block.Servers.Members.Count -eq 0) { $tail = $nl + '  ' }
            [void]$edits.Add((New-Object psobject -Property @{ Start = $block.Servers.Open + 1; End = $block.Servers.Open + 1
                Text = $nl + $joined + $tail }))
        } else {
            $tail = ','
            if ($block.Top.Members.Count -eq 0) { $tail = $nl }
            [void]$edits.Add((New-Object psobject -Property @{ Start = $block.Top.Open + 1; End = $block.Top.Open + 1
                Text = $nl + '  "mcpServers": {' + $nl + $joined + $nl + '  }' + $tail }))
        }
    }
    foreach ($edit in @($edits | Sort-Object Start -Descending)) {
        $text = $text.Substring(0, $edit.Start) + $edit.Text + $text.Substring($edit.End)
    }
    return $text
}

function Remove-Servers([string]$text, [string[]]$names) {
    # The config text without those of the named entries that are ours.
    foreach ($name in $names) {
        $block = Get-ServerBlock $text
        if (-not $block.Servers) { return $text }
        $members = $block.Servers.Members
        $index = -1
        for ($i = 0; $i -lt $members.Count; $i++) { if ($members[$i].Name -ceq $name) { $index = $i } }
        if ($index -lt 0) { continue }
        $member = $members[$index]
        $existing = $script:Json.DeserializeObject($text.Substring($member.ValueStart, $member.ValueEnd - $member.ValueStart))
        if (-not (Test-Ours $existing)) { continue }
        if ($index + 1 -lt $members.Count) { $text = $text.Substring(0, $member.KeyStart) + $text.Substring($members[$index + 1].KeyStart) }
        elseif ($index -gt 0) { $text = $text.Substring(0, $members[$index - 1].ValueEnd) + $text.Substring($member.ValueEnd) }
        else { $text = $text.Substring(0, $block.Servers.Open + 1) + $text.Substring($block.Servers.Close) }
    }
    return $text
}

function Save-Config([string]$path, [string]$old, [string]$new, [bool]$bom, [string[]]$mustHave) {
    # Checks the new text is sound and still has every server the old one had, backs the old file up, then writes.
    $before = @()
    if ($old) {
        $oldBlock = Get-ServerBlock $old
        if ($oldBlock.Servers) { $before = @($oldBlock.Servers.Members | ForEach-Object { $_.Name }) }
    }
    [void]$script:Json.DeserializeObject($new)
    $newBlock = Get-ServerBlock $new
    $after = @()
    if ($newBlock.Servers) { $after = @($newBlock.Servers.Members | ForEach-Object { $_.Name }) }
    foreach ($name in @($before) + @($mustHave)) {
        if ($name -and ($after -cnotcontains $name)) { throw "the new config would lose `"$name`"" }
    }
    if ($old) {
        $backup = '{0}.alexandria-{1}.bak' -f $path, (Get-Date -Format 'yyyyMMdd-HHmmss')
        Copy-Item -LiteralPath $path -Destination $backup -Force
        Log ("backup: " + $backup)
    }
    Write-Atomic $path (Get-Utf8Bytes $new $bom)
}


# ------------------------------------------------------------------ Rhino
function Get-Yak {
    foreach ($version in '8', '9') {
        $folders = @()
        try {
            $key = Get-ItemProperty -Path "HKLM:\SOFTWARE\McNeel\Rhinoceros\$version.0\Install" -ErrorAction Stop
            foreach ($name in 'Path', 'InstallPath') {
                if ($key.PSObject.Properties[$name] -and $key.$name) { $folders += [string]$key.$name }
            }
        } catch { }
        $folders += (Join-Path $env:ProgramFiles "Rhino $version\System")
        foreach ($folder in $folders) {
            foreach ($candidate in (Join-Path $folder 'Yak.exe'), (Join-Path $folder 'System\Yak.exe')) {
                if (Test-Path -LiteralPath $candidate) { return (New-Object psobject -Property @{ Version = $version; Path = $candidate }) }
            }
        }
    }
    return $null
}

function Get-Router {
    # The router of the installed Rhino-MCP-Platform package, as rhino-mcp.cmd finds it.
    $arch = 'win-x64'
    if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { $arch = 'win-arm64' }
    foreach ($version in '8.0', '9.0') {
        $package = Join-Path $env:APPDATA "McNeel\Rhinoceros\packages\$version\$RHINO_PACKAGE"
        $manifest = Join-Path $package 'manifest.txt'
        if (-not (Test-Path -LiteralPath $manifest)) { continue }
        $installed = ([string](Get-Content -LiteralPath $manifest -TotalCount 1)).Trim()
        $router = Join-Path $package "$installed\router\$arch\rhino-mcp-router.exe"
        if (Test-Path -LiteralPath $router) { return $router }
    }
    return $null
}

$LAUNCHER_TEXT = @'
@echo off
rem Alexandria: starts the MCP router of whichever Rhino-MCP-Platform package is installed.
rem Written by Alexandria's install.ps1. Claude runs this; it isn't for double-clicking.
setlocal
set "ARCH=win-x64"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "ARCH=win-arm64"
set "PKG=%APPDATA%\McNeel\Rhinoceros\packages\8.0\Rhino-MCP-Platform"
if not exist "%PKG%\manifest.txt" set "PKG=%APPDATA%\McNeel\Rhinoceros\packages\9.0\Rhino-MCP-Platform"
if not exist "%PKG%\manifest.txt" goto missing
set /p VER=<"%PKG%\manifest.txt"
if not exist "%PKG%\%VER%\router\%ARCH%\rhino-mcp-router.exe" goto missing
"%PKG%\%VER%\router\%ARCH%\rhino-mcp-router.exe" %*
exit /b %ERRORLEVEL%
:missing
echo Rhino-MCP-Platform is not installed in Rhino. Run AlexandriaSetup in Rhino, or install it from Rhino's Package Manager. 1>&2
exit /b 1
'@

function Install-Rhino {
    # Returns our Rhino server entry, or $null when this PC has no Rhino for it.
    $yak = Get-Yak
    $router = Get-Router
    if (-not $router) {
        if (-not $yak) {
            $script:NoteKind = 'absent'; $script:Note = 'Rhino 8 is not on this PC'
            Say '  Rhino 8 is not on this PC, so the Rhino connector is skipped.'; return $null
        }
        $stamp = Join-Path $InstallHome 'rhino-package.failed'
        $yakVersion = (Get-Item -LiteralPath $yak.Path).VersionInfo.FileVersion
        if ($Check -and (Test-Path -LiteralPath $stamp) -and ((Get-Content -LiteralPath $stamp -TotalCount 1) -eq $yakVersion)) {
            $script:NoteKind = 'failed'; $script:Note = "Rhino's package manager could not install $RHINO_PACKAGE last time"
            return $null   # it failed with this Rhino already: updating Rhino, or running this by hand, tries again
        }
        if (-not (Need "install the $RHINO_PACKAGE package in Rhino $($yak.Version)")) { return $null }
        Say "  Installing McNeel's $RHINO_PACKAGE package in Rhino $($yak.Version)..."
        $code = Run-Tool $yak.Path @('install', $RHINO_PACKAGE) $null
        $router = Get-Router
        if (-not $router) {
            Set-Content -LiteralPath $stamp -Value $yakVersion -Encoding ASCII
            Fail "Rhino's package manager could not install $RHINO_PACKAGE (exit code $code). It needs Rhino 8.19 or later and the internet. See $LogFile."
            return $null
        }
        Remove-Item -LiteralPath $stamp -ErrorAction SilentlyContinue
        $script:Changed = $true
        Say '  Installed. Restart Rhino to load it.'
    } else {
        Say "  The $RHINO_PACKAGE package is installed."
    }
    $launcher = Join-Path $InstallHome 'rhino-mcp.cmd'
    $wanted = $LAUNCHER_TEXT -replace "`r?`n", "`r`n"
    $current = $null
    if (Test-Path -LiteralPath $launcher) { $current = [IO.File]::ReadAllText($launcher) }
    if ($current -cne $wanted) {
        if (Need 'write the Rhino launcher') {
            [IO.File]::WriteAllText($launcher, $wanted, (New-Object System.Text.ASCIIEncoding))
            $script:Changed = $true
        }
    }
    $version = '8'
    if ($yak) { $version = $yak.Version }
    return @{ command = $launcher; args = @('--default-version', $version, '--startup-timeout', '120'); env = [ordered]@{} }
}


# ------------------------------------------------------------------ CorelDRAW
function Get-FolderHash([string]$folder) {
    $sha = [Security.Cryptography.SHA256]::Create()
    $lines = New-Object System.Collections.ArrayList
    $files = Get-ChildItem -LiteralPath $folder -Recurse -File | Where-Object {
        $_.FullName -notmatch '\\(\.venv|logs|__pycache__)\\' -and $_.Name -ne 'source.sha256' } | Sort-Object FullName
    foreach ($file in $files) {
        $hash = [BitConverter]::ToString($sha.ComputeHash([IO.File]::ReadAllBytes($file.FullName))) -replace '-', ''
        [void]$lines.Add($file.FullName.Substring($folder.Length).TrimStart('\').ToLowerInvariant() + ' ' + $hash)
    }
    $all = [Text.Encoding]::UTF8.GetBytes(($lines -join "`n"))
    return ([BitConverter]::ToString($sha.ComputeHash($all)) -replace '-', '')
}

function Get-Uv {
    $command = Get-Command uv.exe -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    foreach ($candidate in (Join-Path $env:USERPROFILE '.local\bin\uv.exe'), (Join-Path $InstallHome 'uv\uv.exe')) {
        if (Test-Path -LiteralPath $candidate) { return $candidate }
    }
    return $null
}

function Install-Uv {
    # uv, Astral's Python installer, into our own folder: no PATH or profile changes.
    $folder = Join-Path $InstallHome 'uv'
    Say '  Downloading uv, which installs Python and its packages...'
    $bootstrap = "[Net.ServicePointManager]::SecurityProtocol = 'Tls12'; " +
              "`$env:UV_UNMANAGED_INSTALL = '$($folder -replace "'", "''")'; " +
              "Invoke-RestMethod https://astral.sh/uv/install.ps1 | Invoke-Expression"
    $code = Run-Tool 'powershell.exe' @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', $bootstrap) $null
    $uv = Join-Path $folder 'uv.exe'
    if (Test-Path -LiteralPath $uv) { return $uv }
    Log "uv install exit code $code"
    return $null
}

function Get-UvEnvironment {
    # Pythons uv installs go in our own folder, shared by the servers that need one.
    return @{ UV_PYTHON_INSTALL_DIR = (Join-Path $InstallHome 'python'); UV_PYTHON_PREFERENCE = 'only-managed'
              UV_LINK_MODE = 'copy'; UV_NO_PROGRESS = '1' }
}

function Install-Corel {
    # Returns our CorelDRAW server entry, or $null when this PC has no CorelDRAW or the install failed.
    if (-not (Test-Path 'Registry::HKEY_CLASSES_ROOT\CorelDRAW.Application')) {
        $script:NoteKind = 'absent'; $script:Note = 'CorelDRAW is not on this PC'
        Say '  CorelDRAW is not on this PC, so the CorelDRAW connector is skipped.'
        return $null
    }
    $from = Join-Path $Source 'coreldraw'
    $to = Join-Path $InstallHome 'coreldraw'
    $python = Join-Path $to '.venv\Scripts\python.exe'
    $server = @{ command = $python; args = @((Join-Path $to 'server\server.py'), '--transport', 'stdio')
                 env = [ordered]@{ PYTHONUNBUFFERED = '1'; COREL_ATTACH_POLICY = 'existing_only'; COREL_TOOL_PROFILE = 'compact' } }
    if (-not (Test-Path -LiteralPath (Join-Path $from 'server\server.py'))) {
        Fail "The CorelDRAW server is missing from $from."
        return $null
    }

    # the server's files
    $wanted = Get-FolderHash $from
    $stamp = Join-Path $to 'source.sha256'
    $have = $null
    if (Test-Path -LiteralPath $stamp) { $have = ([string](Get-Content -LiteralPath $stamp -TotalCount 1)).Trim() }
    if ($have -ne $wanted) {
        if (-not (Need 'copy the CorelDRAW server to this PC')) { return $null }
        Say '  Copying the CorelDRAW server...'
        New-Item -ItemType Directory -Force $to | Out-Null
        Remove-Item -LiteralPath (Join-Path $to 'server') -Recurse -Force -ErrorAction SilentlyContinue
        foreach ($item in Get-ChildItem -LiteralPath $from -Force) {
            if ($item.Name -in '.venv', 'logs', '__pycache__') { continue }
            Copy-Item -LiteralPath $item.FullName -Destination $to -Recurse -Force
        }
        Set-Content -LiteralPath $stamp -Value $wanted -Encoding ASCII
        $script:Changed = $true
    }

    # its Python and packages
    $requirements = Join-Path $to 'requirements.txt'
    $wanted = (Get-FileHash -LiteralPath (Join-Path $from 'requirements.txt') -Algorithm SHA256).Hash
    $stamp = Join-Path $to '.venv\requirements.sha256'
    $have = $null
    if (Test-Path -LiteralPath $stamp) { $have = ([string](Get-Content -LiteralPath $stamp -TotalCount 1)).Trim() }
    if ($have -ne $wanted -or -not (Test-Path -LiteralPath $python)) {
        if (-not (Need 'install Python and the packages the CorelDRAW server needs')) { return $null }
        $uv = Get-Uv
        if (-not $uv) { $uv = Install-Uv }
        if (-not $uv) { Fail "uv could not be downloaded from astral.sh. Check the internet connection. See $LogFile."; return $null }
        $environment = Get-UvEnvironment
        Say "  Installing Python $PYTHON_VERSION and the server's packages. This takes a minute or two the first time..."
        $venv = Join-Path $to '.venv'
        if (Test-Path -LiteralPath $venv) {
            try { Remove-Item -LiteralPath $venv -Recurse -Force }
            catch { Fail 'The CorelDRAW server is running, so it could not be updated. Quit Claude, then run this again.'; return $null }
        }
        $code = Run-Tool $uv @('venv', $venv, '--python', $PYTHON_VERSION) $environment
        if ($code -eq 0) { $code = Run-Tool $uv @('pip', 'install', '--python', $python, '--require-hashes', '-r', $requirements) $environment }
        if ($code -eq 0) { $code = Run-Tool $python @('-c', 'import fastmcp, win32com.client, pythoncom, pydantic_settings, loguru, dotenv') $null }
        if ($code -ne 0) {
            Fail "Python or the CorelDRAW server's packages could not be installed (exit code $code). See $LogFile."
            return $null
        }
        Set-Content -LiteralPath $stamp -Value $wanted -Encoding ASCII
        $script:Changed = $true
    }
    Say '  The CorelDRAW server is installed.'
    return $server
}


# ------------------------------------------------------------------ SquareCoil
function Get-SquareCoilUser {
    # The SquareCoil username stored in Credential Manager, or $null when there is none.
    $lines = @(& cmdkey.exe "/list:$SQUARECOIL_TARGET" 2>$null)
    if (-not ($lines -match [regex]::Escape($SQUARECOIL_TARGET))) { return $null }
    foreach ($line in $lines) { if ($line -match '^\s*User:\s*(.+?)\s*$') { return $Matches[1] } }
    return '(stored)'
}

function Install-SquareCoil {
    # Returns our SquareCoil server entry, or $null when it is skipped or the install failed.
    $from = Join-Path $Source 'squarecoil'
    $to = Join-Path $InstallHome 'squarecoil'
    $python = Join-Path $to '.venv\Scripts\python.exe'
    $server = @{ command = $python; args = @('-I', (Join-Path $to 'server.py')); env = [ordered]@{} }
    if (-not (Test-Path -LiteralPath (Join-Path $from 'server.py'))) { Fail "The SquareCoil server is missing from $from."; return $null }
    $skipped = Join-Path $InstallHome 'squarecoil.skipped'
    $user = Get-SquareCoilUser
    if (-not $user -and (Test-Path -LiteralPath $skipped) -and -not $AskLogin) {
        $script:NoteKind = 'skipped'; $script:Note = 'no SquareCoil login: it was skipped'
        Say '  No SquareCoil login, so the SquareCoil connector is skipped. Install Connectors in Rhino asks for it again.'
        return $null
    }

    # the server's files
    $wanted = Get-FolderHash $from
    $stamp = Join-Path $to 'source.sha256'
    $have = $null
    if (Test-Path -LiteralPath $stamp) { $have = ([string](Get-Content -LiteralPath $stamp -TotalCount 1)).Trim() }
    if ($have -ne $wanted) {
        if (-not (Need 'copy the SquareCoil server to this PC')) { return $null }
        Say '  Copying the SquareCoil server...'
        New-Item -ItemType Directory -Force $to | Out-Null
        foreach ($item in Get-ChildItem -LiteralPath $from -Force) {
            if ($item.Name -in '.venv', 'logs', '__pycache__') { continue }
            Copy-Item -LiteralPath $item.FullName -Destination $to -Recurse -Force
        }
        Set-Content -LiteralPath $stamp -Value $wanted -Encoding ASCII
        $script:Changed = $true
    }

    # its Python: the standard library is all it needs
    if (-not (Test-Path -LiteralPath $python)) {
        if (-not (Need 'install Python for the SquareCoil server')) { return $null }
        $uv = Get-Uv
        if (-not $uv) { $uv = Install-Uv }
        if (-not $uv) { Fail "uv could not be downloaded from astral.sh. Check the internet connection. See $LogFile."; return $null }
        Say "  Installing Python $PYTHON_VERSION for the SquareCoil server..."
        $code = Run-Tool $uv @('venv', (Join-Path $to '.venv'), '--python', $PYTHON_VERSION) (Get-UvEnvironment)
        if ($code -ne 0 -or -not (Test-Path -LiteralPath $python)) {
            Fail "Python could not be installed for the SquareCoil server (exit code $code). See $LogFile."
            return $null
        }
        $script:Changed = $true
    }

    # the person's own login, asked for here, in this window
    if (-not $user) {
        if (-not (Need 'sign in to SquareCoil')) { return $null }
        Write-Host ''
        # in this window, with nothing redirected, so it can ask; its output stays out of what this returns
        $login = Start-Process -FilePath $python -ArgumentList ('-I "' + (Join-Path $to 'squarecoil.py') + '" login') `
            -NoNewWindow -Wait -PassThru
        $code = $login.ExitCode
        Write-Host ''
        if ($code -eq $LOGIN_SKIPPED) {
            Set-Content -LiteralPath $skipped -Value (Get-Date -Format 'yyyy-MM-dd') -Encoding ASCII
            $script:NoteKind = 'skipped'; $script:Note = 'no SquareCoil login: it was skipped'
            Say '  SquareCoil skipped. Install Connectors in Rhino asks for the login again.'
            return $null
        }
        $user = Get-SquareCoilUser
        if ($code -ne 0 -or -not $user) { Fail 'No SquareCoil login was stored, so the SquareCoil connector was not added.'; return $null }
        $script:Changed = $true
    }
    Remove-Item -LiteralPath $skipped -ErrorAction SilentlyContinue
    Say "  The SquareCoil server is installed, signed in as $user."
    return $server
}


# ------------------------------------------------------------------ Claude Desktop
function Get-DesktopConfigs {
    # Every Claude Desktop config on this PC. The Microsoft Store build keeps its own under Packages.
    if ($DesktopConfig) { return @($DesktopConfig) }
    $folders = @()
    $packages = Join-Path $env:LOCALAPPDATA 'Packages'
    if (Test-Path -LiteralPath $packages) {
        foreach ($package in Get-ChildItem -LiteralPath $packages -Directory -Filter 'Claude_*' -ErrorAction SilentlyContinue) {
            $folders += (Join-Path $package.FullName 'LocalCache\Roaming\Claude')
        }
    }
    $folders += (Join-Path $env:APPDATA 'Claude')
    $configs = @()
    $seen = @{}
    foreach ($folder in $folders) {
        if (-not (Test-Path -LiteralPath $folder)) { continue }
        $config = Join-Path $folder 'claude_desktop_config.json'
        # inside the Store app's own view both folders are one file
        $identity = $config.ToLowerInvariant()
        if (Test-Path -LiteralPath $config) {
            $item = Get-Item -LiteralPath $config
            $identity = '{0}|{1}' -f $item.Length, $item.LastWriteTimeUtc.Ticks
        }
        if ($seen.ContainsKey($identity)) { continue }
        $seen[$identity] = $true
        $configs += $config
    }
    return $configs
}

function Update-Desktop($servers) {
    $configs = @(Get-DesktopConfigs)
    if (-not $configs.Count) { Say '  Claude Desktop is not on this PC.'; return }
    foreach ($config in $configs) {
        try {
            $mine = [ordered]@{}
            foreach ($name in $servers.Keys) { $mine[$name] = $servers[$name] }
            # McNeel's own Claude Desktop extension is the same connector: no second copy beside it
            $extensions = Join-Path (Split-Path $config) 'Claude Extensions'
            if ($mine.Contains($RHINO_NAME) -and (Test-Path -LiteralPath $extensions) -and
                @(Get-ChildItem -LiteralPath $extensions -Directory -Filter '*rhino-mcp-platform*').Count) {
                $mine.Remove($RHINO_NAME)
                Say "  Claude Desktop already has McNeel's Rhino MCP Platform extension, so no Rhino entry is added."
            }
            if (-not $mine.Count) { continue }
            $old = $null; $bom = $false; $text = '{}'
            if (Test-Path -LiteralPath $config) {
                $read = Read-Text $config
                $old = $read.Text; $bom = $read.Bom
                if ($old.Trim()) { $text = $old } else { $old = $null }
            }
            $plan = Get-Plan $text $mine
            foreach ($name in $plan.Keys) {
                if ($plan[$name] -eq 'foreign') { Say "  Claude Desktop already has its own `"$name`" connector. Left as it is." }
            }
            $work = @($plan.Keys | Where-Object { $plan[$_] -in 'add', 'update' })
            if (-not $work.Count) { Say '  Claude Desktop is up to date.'; continue }
            if (-not (Need ('add ' + ($work -join ' and ') + ' to Claude Desktop'))) { continue }
            $new = Set-Servers $text $mine $plan
            Save-Config $config $old $new $bom $work
            $script:Changed = $true
            $script:RestartDesktop = $true
            Say ('  Added to Claude Desktop: ' + ($work -join ', ') + '.')
        } catch {
            Fail ("Claude Desktop's config was left untouched ($config): " + $_.Exception.Message)
        }
    }
}


# ------------------------------------------------------------------ Claude Code
function Get-ClaudeCode {
    $command = Get-Command claude -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    $candidate = Join-Path $env:USERPROFILE '.local\bin\claude.exe'
    if (Test-Path -LiteralPath $candidate) { return $candidate }
    return $null
}

function Get-ClaudeCodeConfig {
    if ($env:CLAUDE_CONFIG_DIR) { return (Join-Path $env:CLAUDE_CONFIG_DIR '.claude.json') }
    return (Join-Path $env:USERPROFILE '.claude.json')
}

function ConvertTo-NativeArg([string]$text) {
    # A string with quotes in it as one argument of a program: each quote escaped, the backslashes before it doubled.
    return [regex]::Replace($text, '(\\*)"', { param($m) ($m.Groups[1].Value * 2) + '\"' })
}

function Update-ClaudeCode($servers) {
    # Claude Code changes its own config through its command line, so nothing is written behind its back.
    $claude = Get-ClaudeCode
    if (-not $claude) { Say '  Claude Code is not on this PC.'; return }
    try {
        $config = Get-ClaudeCodeConfig
        $text = '{}'
        if (Test-Path -LiteralPath $config) { $text = (Read-Text $config).Text }
        $mine = [ordered]@{}
        foreach ($name in $servers.Keys) {
            $mine[$name] = @{ type = 'stdio'; command = $servers[$name].command; args = $servers[$name].args; env = $servers[$name].env }
        }
        $plan = Get-Plan $text $mine
        foreach ($name in $plan.Keys) {
            if ($plan[$name] -eq 'foreign') { Say "  Claude Code already has its own `"$name`" connector. Left as it is." }
        }
        $work = @($plan.Keys | Where-Object { $plan[$_] -in 'add', 'update' })
        if (-not $work.Count) { Say '  Claude Code is up to date.'; return }
        if (-not (Need ('add ' + ($work -join ' and ') + ' to Claude Code'))) { return }
        foreach ($name in $work) {
            if ($plan[$name] -eq 'update') { [void](Run-Tool $claude @('mcp', 'remove', '--scope', 'user', $name) $null) }
            $entry = ConvertTo-NativeArg (ConvertTo-ServerJson $mine[$name] '' '' $true)
            $code = Run-Tool $claude @('mcp', 'add-json', '--scope', 'user', $name, $entry) $null
            if ($code -ne 0) { Fail "Claude Code would not add `"$name`" (exit code $code). See $LogFile."; continue }
            $script:Changed = $true
            Say "  Added to Claude Code: $name."
        }
    } catch {
        Fail ("Claude Code's config was left untouched: " + $_.Exception.Message)
    }
}


# ------------------------------------------------------------------ uninstall
function Invoke-Uninstall {
    Say 'Removing the Alexandria Claude connectors.'
    $names = @($RHINO_NAME, $COREL_NAME, $SQUARECOIL_NAME)
    if (-not $SkipDesktop) {
        foreach ($config in @(Get-DesktopConfigs)) {
            if (-not (Test-Path -LiteralPath $config)) { continue }
            try {
                $read = Read-Text $config
                $new = Remove-Servers $read.Text $names
                if ($new -cne $read.Text) {
                    [void]$script:Json.DeserializeObject($new)
                    Copy-Item -LiteralPath $config -Destination ('{0}.alexandria-{1}.bak' -f $config, (Get-Date -Format 'yyyyMMdd-HHmmss')) -Force
                    Write-Atomic $config (Get-Utf8Bytes $new $read.Bom)
                    Say '  Taken out of Claude Desktop.'
                }
            } catch { Fail ("Claude Desktop's config was left untouched ($config): " + $_.Exception.Message) }
        }
    }
    $claude = Get-ClaudeCode
    if ($claude -and -not $SkipClaudeCode) {
        try {
            $config = Get-ClaudeCodeConfig
            if (Test-Path -LiteralPath $config) {
                $text = (Read-Text $config).Text
                $block = Get-ServerBlock $text
                foreach ($name in $names) {
                    $member = $null
                    if ($block.Servers) { $member = Find-Member $block.Servers $name }
                    if (-not $member) { continue }
                    $existing = $script:Json.DeserializeObject($text.Substring($member.ValueStart, $member.ValueEnd - $member.ValueStart))
                    if (Test-Ours $existing) {
                        [void](Run-Tool $claude @('mcp', 'remove', '--scope', 'user', $name) $null)
                        Say "  Taken out of Claude Code: $name."
                    }
                }
            }
        } catch { Fail ("Claude Code's config was left untouched: " + $_.Exception.Message) }
    }
    if (Get-SquareCoilUser) {
        [void](& cmdkey.exe "/delete:$SQUARECOIL_TARGET")
        Write-Host '  Took the SquareCoil login out of Windows Credential Manager.'
    }
    if (Test-Path -LiteralPath $InstallHome) {
        try { Remove-Item -LiteralPath $InstallHome -Recurse -Force; Write-Host "  Deleted $InstallHome." }
        catch { Write-Host "  Could not delete all of $InstallHome. Quit Claude and delete it by hand." }
    }
    Write-Host "The $RHINO_PACKAGE package stays in Rhino: uninstall it in Rhino's Package Manager if you want it gone."
}


# ------------------------------------------------------------------ main
$CONNECTORS = [ordered]@{ rhino = 'Rhino'; coreldraw = 'CorelDRAW'; squarecoil = 'SquareCoil' }   # -Only's keys, in install order

function Get-Selected {
    # The connectors to work on: -Only's, comma-separated or not, else all of them.
    if (-not $Only) { return @($CONNECTORS.Keys) }
    $wanted = @($Only | ForEach-Object { $_ -split '[,\s]+' } | Where-Object { $_ } | ForEach-Object { $_.ToLowerInvariant() })
    foreach ($key in $wanted) { if (-not $CONNECTORS.Contains($key)) { throw "-Only: no connector called '$key' (rhino, coreldraw, squarecoil)" } }
    return @($CONNECTORS.Keys | Where-Object { $wanted -contains $_ })
}

function Invoke-Connector([string]$key) {
    # Installs (or, in -Check, looks over) one connector. Its Claude entry's name, the entry or $null, and what it is.
    $script:Note = $null; $script:NoteKind = $null
    switch ($key) {
        'rhino' { return @{ Name = $RHINO_NAME; Server = (Install-Rhino); What = "McNeel's $RHINO_PACKAGE, in Claude" } }
        'coreldraw' { return @{ Name = $COREL_NAME; Server = (Install-Corel); What = 'the CorelDRAW server, in Claude' } }
        'squarecoil' {
            $server = Install-SquareCoil
            return @{ Name = $SQUARECOIL_NAME; Server = $server; What = ('signed in as ' + (Get-SquareCoilUser) + ', in Claude') }
        }
    }
}

$script:RestartDesktop = $false
$exit = 0
try {
    if ($Uninstall) {
        Invoke-Uninstall
    } else {
        Say 'Alexandria: the Claude connectors'
        Say ''
        if (-not $Check -and -not (Test-Path -LiteralPath $InstallHome)) { New-Item -ItemType Directory -Force $InstallHome | Out-Null }
        $selected = @(Get-Selected)
        if ($Status) {
            # each connector told apart: its own to-do list, its program and its Claude entries
            foreach ($key in $selected) {
                $script:Pending.Clear()
                $entry = Invoke-Connector $key
                if ($entry.Server) {
                    $one = [ordered]@{}
                    $one[$entry.Name] = $entry.Server
                    if (-not $SkipDesktop) { Update-Desktop $one }
                    if (-not $SkipClaudeCode) { Update-ClaudeCode $one }
                }
                if ($script:Pending.Count) { $state = 'todo'; $what = ($script:Pending -join '; ') }
                elseif ($script:NoteKind) { $state = $script:NoteKind; $what = $script:Note }
                elseif ($script:Failed.Count) { $state = 'failed'; $what = ($script:Failed -join '; '); $script:Failed.Clear() }
                else { $state = 'ok'; $what = $entry.What }
                Write-Output ("{0}`t{1}`t{2}" -f $key, $state, $what)
            }
            $script:Pending.Clear()
        } else {
            $servers = [ordered]@{}
            foreach ($key in $selected) {
                Say $CONNECTORS[$key]
                $entry = Invoke-Connector $key
                if ($entry.Server) { $servers[$entry.Name] = $entry.Server }
            }
            if ($servers.Count) {
                Say 'Claude'
                if (-not $SkipDesktop) { Update-Desktop $servers }
                if (-not $SkipClaudeCode) { Update-ClaudeCode $servers }
            }
        }
        Say ''
        if ($Status) {
        } elseif ($Check) {
            if ($script:Pending.Count) { Write-Output ($script:Pending -join '; '); $exit = 1 }
        } elseif ($script:Failed.Count) {
            Say 'Not everything went through:'
            foreach ($item in $script:Failed) { Say ('  ' + $item) }
            Say 'Run this again once that is sorted out.'
            $exit = 2
        } elseif ($script:Changed) {
            Say 'Done.'
            if ($script:RestartDesktop) { Say 'Quit Claude Desktop from its tray icon (right-click, Quit) and open it again to see the connectors.' }
        } else {
            Say 'Everything is already set up.'
        }
    }
} catch {
    $exit = 2
    Write-Host ('Stopped: ' + $_.Exception.Message)
    Log ('Stopped: ' + $_.Exception.Message + ' ' + $_.ScriptStackTrace)
}

if (-not $Check -and -not $NoPause) {
    Write-Host ''
    Write-Host 'Press any key to close.'
    try { [void][Console]::ReadKey($true) } catch { }
}
exit $exit
