# Claude connectors for Rhino, CorelDRAW and SquareCoil

Sets a Windows PC up so Claude can work in Rhino, in CorelDRAW and in SquareCoil: the connectors (MCP servers), what they need, and their entries in Claude's settings. **Alexandria Setup** in Rhino runs it for all of them; **Install Connectors**, beside it on the toolbar, shows where each stands and runs it for the ones you tick, or all; so does double-clicking **Install Claude Connectors.cmd** here, for a PC without Rhino. Run either again at any time: it only does what is still missing, and it updates what it installed.

| Connector | What it is | Needs |
|---|---|---|
| `rhino-mcp-platform` | McNeel's own **Rhino-MCP-Platform** package, installed into Rhino from McNeel's package server | Rhino 8.19 or later |
| `coreldraw-live` | The CorelDRAW server in `coreldraw/`, with its own Python | CorelDRAW |
| `squarecoil` | The SquareCoil server in `squarecoil/`: Aria's design request lists, read-only, Python standard library only, with its own Python | The person's own SquareCoil login |

A PC without Rhino skips the first, and one without CorelDRAW the second. SquareCoil asks for the login once, and is skipped if the username is left empty.

## What it does

1. **Rhino.** Installs Rhino-MCP-Platform with Rhino's package manager (`Yak.exe install Rhino-MCP-Platform`) unless it's there, and writes `rhino-mcp.cmd`, which starts the router of whichever version of the package is installed. Claude runs that file, so the connector keeps working when the package updates.
2. **CorelDRAW.** Copies `coreldraw/` to the PC. Downloads [uv](https://docs.astral.sh/uv/) from astral.sh if the PC has none, and with it Python 3.12 and the packages pinned, with hashes, in `coreldraw/requirements.txt`. About 150 MB, a minute or two, once.
3. **SquareCoil.** Copies `squarecoil/` to the PC and gives it a Python 3.12 of its own from uv, with no packages. Asks, in the installer's window, for the person's own SquareCoil login: `squarecoil.py login` checks it against SquareCoil and only then keeps it in Windows Credential Manager as `alexandria/squarecoil/ariasigns`, never in a file. An empty username skips SquareCoil and leaves `squarecoil.skipped`, so Setup stops asking; Install Connectors (`-AskLogin`) asks again. `squarecoil/README.md` says what it reads and what breaks it.
4. **Claude.** Adds them to Claude Desktop (`claude_desktop_config.json`, in the Microsoft Store build's own folder too) and to Claude Code (through `claude mcp add-json --scope user`), whichever are installed.

Everything it puts on the PC is in `%USERPROFILE%\.alexandria\claude_connectors`, with `install.log`. Nothing goes on the PATH, and nothing needs an administrator.

## What it never does

- **It doesn't rewrite a Claude config.** It backs the file up beside it (`claude_desktop_config.json.alexandria-<date>.bak`), puts our entries into the file's own text, and checks the result still reads as JSON and still has every connector it had, before swapping it in. A config it can't read is left alone, and said so.
- **It doesn't replace somebody's own connector.** An entry named `rhino-mcp-platform`, `coreldraw-live` or `squarecoil` that points anywhere but its own folder stays as it is. Nor does it add the Rhino entry to a Claude Desktop that has McNeel's **Rhino MCP Platform** extension, which is the same connector.
- **It doesn't install Claude.** With neither Claude Desktop nor Claude Code on the PC, the connectors are installed and wait: run it again once Claude is there.

## Run it by hand

```
powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1 [-Only rhino,coreldraw,squarecoil] [-Check] [-Status] [-AskLogin] [-Uninstall] [-NoPause]
```

- `-Only` works on just the connectors named, by key, comma-separated. All of them by default.
- `-Check` changes nothing and exits 1 when there is something to do, 0 when there isn't. Alexandria Setup asks this first, and opens the installer's window only when there is.
- `-Status` changes nothing and prints a line per connector, `key<TAB>state<TAB>what`, the state `ok`, `todo`, `absent` (its program isn't on the PC), `skipped` or `failed`. Install Connectors lists these.
- `-AskLogin` asks for the SquareCoil login even after it was skipped.
- `-Uninstall` takes its entries out of the Claude configs and the SquareCoil login out of Credential Manager, and deletes its folder. The Rhino package stays: uninstall it in Rhino's Package Manager.

After it adds something, quit Claude Desktop from its tray icon and open it again. The connectors then show under **Settings › Developer**. The CorelDRAW one works on the document open in CorelDRAW, and never starts CorelDRAW by itself.

## Where it goes

`tools/build.py` puts this folder in the Rhino Tools package (`shared/claude_connectors/`), `tools/release.py` puts it on the office drive beside the packages, and the hub's `tools/sync.py` zips it for the Downloads page. `coreldraw/README.md` says where the CorelDRAW server comes from and what was changed in it. The hub's zip is public, so nothing here may hold SquareCoil data: the SquareCoil tests and their saved dashboard page stay in the private `alexandria_management` repo (`agent_connectors/squarecoil/`).
