# Claude connectors for Rhino and CorelDRAW

Sets a Windows PC up so Claude can work in Rhino and in CorelDRAW: the two connectors (MCP servers), what they need, and their entries in Claude's settings. **Alexandria Setup** in Rhino runs it; so does double-clicking **Install Claude Connectors.cmd** here, for a PC without Rhino. Run either again at any time: it only does what is still missing, and it updates what it installed.

| Connector | What it is | Needs |
|---|---|---|
| `rhino-mcp-platform` | McNeel's own **Rhino-MCP-Platform** package, installed into Rhino from McNeel's package server | Rhino 8.19 or later |
| `coreldraw-live` | The CorelDRAW server in `coreldraw/`, with its own Python | CorelDRAW |

A PC without Rhino skips the first, and one without CorelDRAW skips the second.

## What it does

1. **Rhino.** Installs Rhino-MCP-Platform with Rhino's package manager (`Yak.exe install Rhino-MCP-Platform`) unless it's there, and writes `rhino-mcp.cmd`, which starts the router of whichever version of the package is installed. Claude runs that file, so the connector keeps working when the package updates.
2. **CorelDRAW.** Copies `coreldraw/` to the PC. Downloads [uv](https://docs.astral.sh/uv/) from astral.sh if the PC has none, and with it Python 3.12 and the packages pinned, with hashes, in `coreldraw/requirements.txt`. About 150 MB, a minute or two, once.
3. **Claude.** Adds the two to Claude Desktop (`claude_desktop_config.json`, in the Microsoft Store build's own folder too) and to Claude Code (through `claude mcp add-json --scope user`), whichever are installed.

Everything it puts on the PC is in `%USERPROFILE%\.alexandria\claude_connectors`, with `install.log`. Nothing goes on the PATH, and nothing needs an administrator.

## What it never does

- **It doesn't rewrite a Claude config.** It backs the file up beside it (`claude_desktop_config.json.alexandria-<date>.bak`), puts the two entries into the file's own text, and checks the result still reads as JSON and still has every connector it had, before swapping it in. A config it can't read is left alone, and said so.
- **It doesn't replace somebody's own connector.** An entry named `rhino-mcp-platform` or `coreldraw-live` that points anywhere but its own folder stays as it is. Nor does it add the Rhino entry to a Claude Desktop that has McNeel's **Rhino MCP Platform** extension, which is the same connector.
- **It doesn't install Claude.** With neither Claude Desktop nor Claude Code on the PC, the connectors are installed and wait: run it again once Claude is there.

## Run it by hand

```
powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1 [-Check] [-Uninstall] [-NoPause]
```

- `-Check` changes nothing and exits 1 when there is something to do, 0 when there isn't. Alexandria Setup asks this first, and opens the installer's window only when there is.
- `-Uninstall` takes its entries out of the Claude configs and deletes its folder. The Rhino package stays: uninstall it in Rhino's Package Manager.

After it adds something, quit Claude Desktop from its tray icon and open it again. Both connectors then show under **Settings › Developer**. The CorelDRAW one works on the document open in CorelDRAW, and never starts CorelDRAW by itself.

## Where it goes

`tools/build.py` puts this folder in the Rhino Tools package (`shared/claude_connectors/`), `tools/release.py` puts it on the office drive beside the packages, and the hub's `tools/sync.py` zips it for the Downloads page. `coreldraw/README.md` says where the CorelDRAW server comes from and what was changed in it.
