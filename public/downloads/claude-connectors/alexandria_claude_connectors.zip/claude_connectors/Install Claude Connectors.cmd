@echo off
rem Alexandria: installs the Claude connectors (MCP) for Rhino and CorelDRAW on this PC.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
