# Alexandria Braille

A braille font for signs. Set at **36 pt, with lines 28.8 pt apart**, it prints at the sizes the office uses for ADA
braille, the Braille Lettering Designer's defaults:

| | Inches | ADA 703.3.1 allows |
| --- | --- | --- |
| A dot's diameter | 0.06 | 0.059 to 0.063 |
| Dots apart in a cell, centre to centre | 0.1 | 0.09 to 0.1 |
| Cells apart, centre to centre | 0.25 | 0.241 to 0.3 |
| Lines apart, centre to centre | 0.4 | 0.395 to 0.4 |

Every dot is a filled circle, a closed outline, since a braille dot is a raised or printed shape: convert the text to
curves and each dot is one circle, ready to rout, cut or print. See `specimen.pdf`.

## What it has

- **The 256 braille patterns of Unicode, U+2800 to U+28FF**: the 64 six-dot cells, and the eight-dot ones with dots 7
  and 8 under them. Braille copied from the Braille Lettering Designer, or from any translator that gives Unicode
  braille, sets as it is.
- **The space**, a blank cell.
- **The letters a to z**, typed in either case: each letter's own cell, uncontracted. For mock-ups.

Numbers and punctuation have no glyph, on purpose: typed, they show as an empty frame or in another font. Their
braille takes cells a font can't add (the number sign before `101`, a capital's dot 6), and ADA signs need contracted
(Grade 2) braille, where `restroom` is seven cells, not eight. That is translation. For a sign, translate the text in
the [Braille Lettering Designer](https://alexdesignlab.org/braille/) and paste its braille characters.

## Use

1. Install `AlexandriaBraille.ttf` (right-click, Install).
2. Paste the braille characters and set them in Alexandria Braille at 36 pt.
3. Set the lines 28.8 pt apart (0.4 in). Software that takes a line's height from the font gets that on its own, but
   Illustrator's automatic leading, 120% of the size, does not, and a browser rounds it to the pixel.

Dot 3 sits on the baseline. For another size, the scale is the point size over 36.

In Rhino the Braille Lettering Designer's SVG is still the way: it comes in as one circle per dot. The font hasn't been
tried as Rhino text.

## Files

| File | For |
| --- | --- |
| `AlexandriaBraille.ttf` | The font. |
| `specimen.pdf` | The specimen sheet. Printed at 100% its braille is at real size. |
| `alexandria_braille.json` | The sizes the font was built from, in inches, and the letters' dots. |
