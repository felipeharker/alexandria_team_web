"""squarecoil: an MCP server (stdio) that gives Claude Aria's SquareCoil: design requests, projects, customers, files.

    python server.py                       stdio: the client (Claude, or any other that runs a command) starts it
    python server.py --http [--port 8765]  HTTP: for a client that takes a URL, http://127.0.0.1:8765/mcp

Python standard library only: it speaks MCP's JSON-RPC itself, over stdin and stdout one message
per line, or over MCP's Streamable HTTP on this PC only, and logs to stderr. The work is
done beside it: squarecoil.py signs in and has the command line, projects.py reads the projects.
"""
from __future__ import annotations

import json
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import projects  # noqa: E402
import squarecoil  # noqa: E402

SERVER_INFO = {"name": "squarecoil", "version": "2.0.0"}
PROTOCOL_VERSIONS = ("2025-06-18", "2025-03-26", "2024-11-05")
CACHE_SECONDS = 60
READ_ONLY = {"readOnlyHint": True, "openWorldHint": True}
INSTRUCTIONS = (
    "Aria's SquareCoil (the sign shop's project system), read-only, as the signed-in person sees it. "
    "To find a project by address, client, name or number use search_projects; get_project then gives everything "
    "about it (client and contacts, scope of work, notes, designs, tasks, files); download_file saves one of its "
    "files to this PC. list_design_requests is the design department's queue. Nothing here changes SquareCoil, "
    "but SquareCoil's activity log shows each project tab that was opened under the person's name."
)

TOOLS = [
    {
        "name": "list_design_requests",
        "title": "List SquareCoil design requests",
        "description": (
            "Aria's design requests from SquareCoil, live from its dashboard (the Design Requests view). "
            "Each has section (In Progress, Next Job or On Hold), design_id (like 260574-01), description "
            "(client and job), created_by, type (Presentation, Production, Pre-Production, Revision, Permits "
            "Required, Const. Dwgs.), date (requested), due_date, assigned_to, overdue (SquareCoil shows the "
            "due date in red), flagged (SquareCoil's red warning triangle), design_key (for "
            "get_design_request) and url. Dates are YYYY-MM-DD. Every filter is optional and they combine."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "section": {"type": "string", "description": "In Progress (the default), Next Job, On Hold, or all."},
                "assigned_to": {"type": "string", "description": "Part of the designer's name, any case."},
                "search": {"type": "string", "description": "Text to find in the design id, description, people or type."},
                "overdue_only": {"type": "boolean", "description": "Only those SquareCoil marks overdue."},
                "due_by": {"type": "string", "description": "Only those due on or before this date, YYYY-MM-DD."},
                "limit": {"type": "integer", "description": "Most rows to return (default 200)."},
            },
            "additionalProperties": False,
        },
        "annotations": {"readOnlyHint": True, "openWorldHint": True},
    },
    {
        "name": "get_design_request",
        "title": "Get one SquareCoil design request",
        "description": (
            "The details of one design request: the text of the pop-up its info icon opens on the SquareCoil "
            "dashboard (project and design notes). Takes design_key from list_design_requests, not the design_id."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {"design_key": {"type": "string", "description": "SquareCoil's number for the design, like 6126."}},
            "required": ["design_key"],
            "additionalProperties": False,
        },
        "annotations": READ_ONLY,
    },
    {
        "name": "search_projects",
        "title": "Search SquareCoil projects",
        "description": (
            "Find projects in SquareCoil (its Existing Projects search), newest first, 25 to a page. Give `query` "
            "when you don't know which field holds the text: a project number is looked up as one, anything else is "
            "tried against project name, site address, billing name, description and city, and each match says "
            "which (matched_on). Or give fields, which combine: every one must match, as part of the text, any "
            "case. Each project has project_number (for get_project), name, address (the site), salesperson, "
            "status, created and url. `matching` is how many there are in all and `pages` how many pages."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Free text or a project number, like 'W Gray' or 260675."},
                "number": {"type": "string", "description": "Project number, or the start of one (2606)."},
                "name": {"type": "string", "description": "Project name, usually the client or the place."},
                "address": {"type": "string", "description": "Site street address, like '2026 W Gray'."},
                "city": {"type": "string"},
                "state": {"type": "string", "description": "Two letters, like TX."},
                "description": {"type": "string", "description": "Text in the scope of work."},
                "billing_name": {"type": "string", "description": "The customer the project bills to."},
                "purchase_order": {"type": "string"},
                "salesperson": {"type": "string", "description": "Full name, as SquareCoil has it."},
                "project_manager": {"type": "string", "description": "Full name, as SquareCoil has it."},
                "status": {"type": "string", "enum": list(projects.STATUSES),
                           "description": "The project's status. All Pending and All Active cover their groups."},
                "page": {"type": "integer", "description": "Which page of 25 (default 1). Not used with query."},
            },
            "additionalProperties": False,
        },
        "annotations": READ_ONLY,
    },
    {
        "name": "get_project",
        "title": "Get one SquareCoil project",
        "description": (
            "Everything SquareCoil has on one project. Always: name, status, alert (such as days overdue), "
            "site_address, open_date, salesperson, project_manager, project_contact and site_contact (name, phone, "
            "email), billing (the customer it bills to, their address and contact), important_notes and "
            "scope_of_work. `include` adds the project's other tabs: designs (each design request with its "
            "description, revisions, hours and files), status (each milestone's dates and notes), tasks (with their "
            "messages), documents, photos, production_files (each file with a url for download_file), contacts, "
            "activity (the log of changes, and emails_sent) and costs (cost to date). Use all for the lot; ask "
            "only for what the question needs, since each part is another page of SquareCoil's."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "project_number": {"type": "string", "description": "SquareCoil's project number, like 260675."},
                "include": {"type": "array", "items": {"type": "string", "enum": [*projects.TABS, "all"]},
                            "description": "The tabs to add to the overview."},
                "activity_views": {"type": "boolean", "description": "With activity: also who opened which tab, "
                                                                     "which is most of the log. Off by default."},
            },
            "required": ["project_number"],
            "additionalProperties": False,
        },
        "annotations": READ_ONLY,
    },
    {
        "name": "search_customers",
        "title": "Search SquareCoil customers",
        "description": (
            "SquareCoil's customer records (the companies projects bill to): those whose name, address, city, zip "
            "or sales rep has the text. Each has customer_id, name, address and sales_rep. For a customer's "
            "projects, pass its name to search_projects as billing_name."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "search": {"type": "string", "description": "Part of the name or address. Empty lists them all, A to Z."},
                "limit": {"type": "integer", "description": "Most customers to return (default 25, at most 200)."},
            },
            "additionalProperties": False,
        },
        "annotations": READ_ONLY,
    },
    {
        "name": "download_file",
        "title": "Download a SquareCoil project file",
        "description": (
            "Save one file from a project to this PC and say where it is, so it can be opened or read. Takes the "
            "url of a file from get_project's documents, photos, production_files or a design's files. It goes to "
            "the Downloads folder, in SquareCoil and then the project number, unless a folder is given, and "
            "replaces a file of the same name there."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "A file's url, as get_project gave it."},
                "folder": {"type": "string", "description": "A folder on this PC to save into instead."},
            },
            "required": ["url"],
            "additionalProperties": False,
        },
        "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
    },
]
TOOL_NAMES = {t["name"] for t in TOOLS}


class Server:
    def __init__(self) -> None:
        self.sc = squarecoil.SquareCoil()
        self._rows: list[dict] = []
        self._fetched = 0.0

    def rows(self) -> tuple[list[dict], float]:
        if time.time() - self._fetched > CACHE_SECONDS:
            self._rows = self.sc.design_requests()
            self._fetched = time.time()
        return self._rows, self._fetched

    def list_design_requests(self, section: str = "In Progress", assigned_to: str = "", search: str = "",
                             overdue_only: bool = False, due_by: str = "", limit: int = 200) -> dict:
        rows, fetched = self.rows()
        section = "" if section.strip().lower() == "all" else section
        found = squarecoil.filter_designs(rows, section=section, assigned_to=assigned_to, search=search,
                                          overdue_only=overdue_only, due_by=due_by)
        return {
            "fetched_at": datetime.fromtimestamp(fetched).isoformat(timespec="seconds"),
            "matching": len(found),
            "returned": min(len(found), limit),
            "total_on_dashboard": len(rows),
            "design_requests": found[:max(0, limit)],
        }

    def get_design_request(self, design_key: str) -> dict:
        return {"design_key": design_key, "details": self.sc.design_details(design_key)}

    def search_projects(self, query: str = "", page: int = 1, **fields: str) -> dict:
        return projects.search(self.sc, query, page, **fields)

    def get_project(self, project_number: str, include: list[str] | None = None, activity_views: bool = False) -> dict:
        return projects.read(self.sc, project_number, include or [], activity_views)

    def search_customers(self, search: str = "", limit: int = 25) -> dict:
        return projects.customers(self.sc, search, limit)

    def download_file(self, url: str, folder: str = "") -> dict:
        return projects.download(self.sc, url, folder)

    def call(self, name: str, arguments: dict) -> dict:
        try:
            if name not in TOOL_NAMES:
                return {"content": [{"type": "text", "text": f"Unknown tool: {name}"}], "isError": True}
            result = getattr(self, name)(**arguments)
            return {"content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}], "isError": False}
        except (squarecoil.SquareCoilError, TypeError, ValueError) as e:
            return {"content": [{"type": "text", "text": str(e)}], "isError": True}

    def handle(self, msg: dict) -> dict | None:
        method, mid = msg.get("method"), msg.get("id")
        if mid is None:  # a notification: nothing to answer
            return None
        params = msg.get("params") or {}
        if method == "initialize":
            asked = params.get("protocolVersion")
            result = {
                "protocolVersion": asked if asked in PROTOCOL_VERSIONS else PROTOCOL_VERSIONS[0],
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": SERVER_INFO,
                "instructions": INSTRUCTIONS,
            }
        elif method == "ping":
            result = {}
        elif method == "tools/list":
            result = {"tools": TOOLS}
        elif method == "tools/call":
            result = self.call(params.get("name", ""), params.get("arguments") or {})
        else:
            return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": f"Method not found: {method}"}}
        return {"jsonrpc": "2.0", "id": mid, "result": result}


LOCAL_HOSTS = ("127.0.0.1", "localhost", "::1")
HTTP_PORT = 8765


def http_server(port: int = HTTP_PORT):
    """The same server over MCP's Streamable HTTP, for clients that take a URL instead of starting a
    program: http://127.0.0.1:<port>/mcp. It listens on this PC only and answers this PC only (a web page
    in a browser here is turned away by its Origin), so it uses the login stored on this PC like stdio does.
    Each POST is one JSON-RPC message, or a list of them, answered as JSON; it opens no event stream."""
    import threading
    import urllib.parse
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    server, one_at_a_time = Server(), threading.Lock()

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def answer(self, status: int, body: object = None, headers: dict | None = None) -> None:
            data = b"" if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            if data:
                self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            for key, value in (headers or {}).items():
                self.send_header(key, value)
            self.end_headers()
            self.wfile.write(data)

        def from_here(self) -> bool:
            host = urllib.parse.urlsplit("//" + (self.headers.get("Host") or "")).hostname
            origin = self.headers.get("Origin")
            return host in LOCAL_HOSTS and (not origin or urllib.parse.urlsplit(origin).hostname in LOCAL_HOSTS)

        def do_POST(self) -> None:
            if not self.from_here():
                return self.answer(403, {"error": "This server answers this PC only."})
            if urllib.parse.urlsplit(self.path).path.rstrip("/") not in ("/mcp", ""):
                return self.answer(404, {"error": "The MCP endpoint is /mcp."})
            try:
                msg = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)))
            except ValueError:
                return self.answer(400, {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}})
            replies = []
            for one in msg if isinstance(msg, list) else [msg]:
                if not isinstance(one, dict):
                    reply = {"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "Invalid request"}}
                else:
                    try:
                        with one_at_a_time:  # one SquareCoil session, used by one request at a time
                            reply = server.handle(one)
                    except Exception as e:  # keep serving; say what broke
                        traceback.print_exc(file=sys.stderr)
                        reply = {"jsonrpc": "2.0", "id": one.get("id"), "error": {"code": -32603, "message": str(e)}}
                if reply is not None:
                    replies.append(reply)
            if not replies:
                return self.answer(202)  # notifications only: nothing to say
            self.answer(200, replies if isinstance(msg, list) else replies[0])

        def do_GET(self) -> None:  # no event stream to open, and no session to end
            self.answer(405, {"error": "POST JSON-RPC to /mcp."}, {"Allow": "POST"})

        do_DELETE = do_GET

        def log_message(self, fmt, *args):
            print("squarecoil http: " + fmt % args, file=sys.stderr)

    return ThreadingHTTPServer(("127.0.0.1", port), Handler)


def main() -> None:
    if "--http" in sys.argv[1:]:
        port = int(sys.argv[sys.argv.index("--port") + 1]) if "--port" in sys.argv else HTTP_PORT
        httpd = http_server(port)
        print(f"squarecoil: MCP over HTTP at http://127.0.0.1:{httpd.server_address[1]}/mcp (Ctrl+C stops it)", file=sys.stderr)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass
        return
    server = Server()
    out = sys.stdout.buffer
    for line in sys.stdin.buffer:
        if not line.strip():
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            reply = {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}}
        else:
            try:
                reply = server.handle(msg)
            except Exception as e:  # keep serving; say what broke
                traceback.print_exc(file=sys.stderr)
                reply = {"jsonrpc": "2.0", "id": msg.get("id"), "error": {"code": -32603, "message": str(e)}}
        if reply is not None:
            out.write(json.dumps(reply, ensure_ascii=False).encode("utf-8") + b"\n")
            out.flush()


if __name__ == "__main__":
    main()
