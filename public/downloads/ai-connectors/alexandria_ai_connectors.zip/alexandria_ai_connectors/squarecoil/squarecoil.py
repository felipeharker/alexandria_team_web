"""SquareCoil: sign in to Aria's SquareCoil and read its design requests, projects, customers and files.

    python squarecoil.py login                 sign in once; the login goes to Windows Credential Manager
    python squarecoil.py designs [--json]      print the dashboard's design request lists
    python squarecoil.py design 5489           print one design request's details
    python squarecoil.py parse FILE.htm        parse a saved dashboard page (no network)
    python squarecoil.py search "W Gray"       find projects (or --address, --name, --billing-name, --status ...)
    python squarecoil.py project 260675 --include all     one project as JSON
    python squarecoil.py customers soto        find customers
    python squarecoil.py download URL          save one project file to Downloads\\SquareCoil

server.py serves the same functions to Claude as MCP tools. Python standard library only.
This file signs in and is the only one that talks to SquareCoil; projects.py reads the project pages.

SquareCoil has no API. This signs in through its login form (login.php, a plain POST) and reads
the pages a browser would, only the ones in READ_PAGES and never one that changes anything. The
design request lists are what dashboard.php?show=2 loads into its page (a POST to
dashboard_designs.php, action=1), so they break only if SquareCoil changes those lists' layout.
Each person signs in with their own SquareCoil login, once: `login` checks it against SquareCoil
and keeps it in Windows Credential Manager under the name in CREDENTIAL_TARGET, never in a file.
Alexandria's connector installer (../install.ps1) runs `login` the first time.
"""
from __future__ import annotations

import argparse
import getpass
import html
import http.cookiejar
import json
import re
import sys
import urllib.parse
import urllib.request
from datetime import date, datetime
from html.parser import HTMLParser

BASE_URL = "https://ariasigns.squarecoil.net/"
# dashboard.php?show=2 is an empty shell: its script posts here and drops the lists into the page.
DESIGNS_PATH = "dashboard_designs.php"
DESIGNS_FORM = {"action": "1", "multiple_location_id": ""}
CREDENTIAL_TARGET = "alexandria/squarecoil/ariasigns"
TIMEOUT = 30
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) alexandria-squarecoil/1.0"

# The dashboard's three lists, by the id of their container, in page order.
SECTIONS = {"inProgress": "In Progress", "nextJob": "Next Job", "onHold": "On Hold"}
COLUMNS = ("date", "design_id", "description", "created_by", "type", "due_date", "assigned_to")


class SquareCoilError(RuntimeError):
    pass


# --- the login, in Windows Credential Manager ------------------------------------------------

def _credential_api():
    if sys.platform != "win32":
        raise SquareCoilError("The SquareCoil login is kept in Windows Credential Manager, so this runs on Windows only.")
    import ctypes
    from ctypes import wintypes

    class CREDENTIAL(ctypes.Structure):
        _fields_ = [
            ("Flags", wintypes.DWORD), ("Type", wintypes.DWORD), ("TargetName", wintypes.LPWSTR),
            ("Comment", wintypes.LPWSTR), ("LastWritten", wintypes.FILETIME),
            ("CredentialBlobSize", wintypes.DWORD), ("CredentialBlob", ctypes.POINTER(ctypes.c_char)),
            ("Persist", wintypes.DWORD), ("AttributeCount", wintypes.DWORD), ("Attributes", ctypes.c_void_p),
            ("TargetAlias", wintypes.LPWSTR), ("UserName", wintypes.LPWSTR),
        ]

    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    advapi.CredReadW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(ctypes.POINTER(CREDENTIAL))]
    advapi.CredReadW.restype = wintypes.BOOL
    advapi.CredWriteW.argtypes = [ctypes.POINTER(CREDENTIAL), wintypes.DWORD]
    advapi.CredWriteW.restype = wintypes.BOOL
    advapi.CredFree.argtypes = [ctypes.c_void_p]
    return ctypes, CREDENTIAL, advapi


CRED_TYPE_GENERIC = 1
CRED_PERSIST_LOCAL_MACHINE = 2


def read_login() -> tuple[str, str]:
    ctypes, CREDENTIAL, advapi = _credential_api()
    pointer = ctypes.POINTER(CREDENTIAL)()
    if not advapi.CredReadW(CREDENTIAL_TARGET, CRED_TYPE_GENERIC, 0, ctypes.byref(pointer)):
        raise SquareCoilError(
            "No SquareCoil login is stored on this PC. Sign in with Install Connectors on Rhino's Alexandria "
            f"Tools tab, or run `python squarecoil.py login` (it is kept in Windows Credential Manager as {CREDENTIAL_TARGET})."
        )
    try:
        cred = pointer.contents
        password = ctypes.string_at(cred.CredentialBlob, cred.CredentialBlobSize).decode("utf-16-le")
        return cred.UserName or "", password
    finally:
        advapi.CredFree(pointer)


def write_login(username: str, password: str) -> None:
    ctypes, CREDENTIAL, advapi = _credential_api()
    blob = password.encode("utf-16-le")
    buffer = ctypes.create_string_buffer(blob, len(blob))
    cred = CREDENTIAL()
    cred.Type = CRED_TYPE_GENERIC
    cred.TargetName = CREDENTIAL_TARGET
    cred.Comment = "SquareCoil login for Alexandria's agent connector"
    cred.CredentialBlobSize = len(blob)
    cred.CredentialBlob = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_char))
    cred.Persist = CRED_PERSIST_LOCAL_MACHINE
    cred.UserName = username
    if not advapi.CredWriteW(ctypes.byref(cred), 0):
        raise SquareCoilError(f"Windows Credential Manager refused the login (error {ctypes.get_last_error()}).")


# --- parsing the dashboard ----------------------------------------------------------------------

class _DashboardParser(HTMLParser):
    """Collects the rows of each design-list-container: one div.row per design request,
    eight column divs in it (col0 icons, then the seven columns in COLUMNS)."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[dict] = []
        self._section: str | None = None
        self._section_depth = 0
        self._row: dict | None = None
        self._row_depth = 0
        self._cell: list[str] | None = None
        self._cell_depth = 0
        self._depth = 0  # div nesting

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        classes = (a.get("class") or "").split()
        if tag == "div":
            self._depth += 1
            if a.get("class") == "design-list-container" and a.get("id") in SECTIONS:
                self._section, self._section_depth = a["id"], self._depth
            elif self._section and self._row is None and "row" in classes:
                href = a.get("href") or ""
                query = urllib.parse.parse_qs(urllib.parse.urlsplit(html.unescape(href)).query)
                self._row = {
                    "section": SECTIONS[self._section],
                    "design_key": (query.get("designid") or [""])[0],
                    "project_number": (query.get("id") or [""])[0],
                    "url": urllib.parse.urljoin(BASE_URL, html.unescape(href)) if href else "",
                    "flagged": False, "overdue": False, "cells": [],
                }
                self._row_depth = self._depth
            elif self._row is not None and self._depth == self._row_depth + 1:
                self._cell, self._cell_depth = [], self._depth
        elif self._row is not None:
            if tag == "i" and "fa-exclamation-triangle" in classes:
                self._row["flagged"] = True
            elif tag == "font" and (a.get("color") or "").lower() == "red":
                self._row["overdue"] = True
            elif tag == "br" and self._cell is not None:
                self._cell.append("\n")

    def handle_startendtag(self, tag, attrs):
        if tag == "br" and self._cell is not None:
            self._cell.append("\n")

    def handle_endtag(self, tag):
        if tag != "div":
            return
        if self._cell is not None and self._depth == self._cell_depth:
            self._row["cells"].append("".join(self._cell))
            self._cell = None
        elif self._row is not None and self._depth == self._row_depth:
            self._finish_row()
        elif self._section and self._depth == self._section_depth:
            self._section = None
        self._depth -= 1

    def handle_data(self, data):
        if self._cell is not None:
            self._cell.append(data)

    def _finish_row(self):
        row, self._row = self._row, None
        cells = [_clean(c) for c in row.pop("cells")]
        if len(cells) < 1 + len(COLUMNS):
            return
        row.update(zip(COLUMNS, cells[1:1 + len(COLUMNS)]))
        row["type"] = _types(row["type"])
        for key in ("date", "due_date"):
            row[key] = _iso(row[key])
        self.rows.append(row)


def _clean(text: str) -> str:
    lines = [" ".join(line.replace("\xa0", " ").split()) for line in text.split("\n")]
    return "\n".join(line for line in lines if line)


# SquareCoil puts a <br> after every word of the Type column, so the two-word types come apart.
TWO_WORD_TYPES = {("Permits", "Required"), ("Const.", "Dwgs.")}


def _types(text: str) -> list[str]:
    words = [w.strip() for w in text.split("\n") if w.strip()]
    out: list[str] = []
    i = 0
    while i < len(words):
        if i + 1 < len(words) and (words[i], words[i + 1]) in TWO_WORD_TYPES:
            out.append(f"{words[i]} {words[i + 1]}")
            i += 2
        else:
            out.append(words[i])
            i += 1
    return out


def _iso(text: str) -> str:
    try:
        return datetime.strptime(text, "%m/%d/%Y").date().isoformat()
    except ValueError:
        return text


def parse_dashboard(page: str) -> list[dict]:
    """The design requests in the dashboard's design lists (dashboard_designs.php, or a saved show=2 page), in page order.

    Each is a dict: section, date, design_id, description, created_by, type (a list), due_date,
    assigned_to (dates as YYYY-MM-DD), overdue (due date shown in red), flagged (the red warning
    triangle), design_key and project_number (SquareCoil's own ids) and url.
    """
    if "design-list-container" not in page:
        raise SquareCoilError("This page has no design request lists. SquareCoil may have changed the dashboard's layout.")
    parser = _DashboardParser()
    parser.feed(page)
    parser.close()
    return parser.rows


def filter_designs(rows: list[dict], section: str = "", assigned_to: str = "", search: str = "",
                   overdue_only: bool = False, due_by: str = "") -> list[dict]:
    """Keep the rows that match every filter given. Text filters ignore case and match any part."""
    out = []
    for r in rows:
        if section and section.lower().replace(" ", "") not in r["section"].lower().replace(" ", ""):
            continue
        if assigned_to and assigned_to.lower() not in r["assigned_to"].lower():
            continue
        if search:
            hay = " ".join([r["design_id"], r["description"], r["created_by"], r["assigned_to"], " ".join(r["type"])]).lower()
            if search.lower() not in hay:
                continue
        if overdue_only and not r["overdue"]:
            continue
        if due_by and not (re.fullmatch(r"\d{4}-\d{2}-\d{2}", r["due_date"]) and r["due_date"] <= due_by):
            continue
        out.append(r)
    return out


class _TextParser(HTMLParser):
    BLOCK = {"p", "div", "br", "tr", "li", "h1", "h2", "h3", "h4", "h5", "h6", "table"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self._skip += 1
        elif tag in self.BLOCK:
            self.parts.append("\n")
        elif tag in ("td", "th"):
            self.parts.append(" | ")

    def handle_endtag(self, tag):
        if tag in ("script", "style") and self._skip:
            self._skip -= 1
        elif tag in self.BLOCK:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self._skip:
            self.parts.append(data)


def html_to_text(fragment: str) -> str:
    p = _TextParser()
    p.feed(fragment)
    p.close()
    return _clean("".join(p.parts))


# --- the session --------------------------------------------------------------------------------

# The only pages this ever asks SquareCoil for. SquareCoil changes things on a plain link
# (project_designs.php?...&action=2 deletes a design), so a request is refused unless its page is
# here, it sends no field but the ones named, and the fields given a value have that value.
_PROJECT = {"id": None}
READ_PAGES = {
    "GET": {
        "project.php": _PROJECT, "project_milestones.php": _PROJECT, "project_documents.php": _PROJECT,
        "project_site_photos.php": _PROJECT, "project_production_files.php": _PROJECT,
        "project_cost_to_date.php": _PROJECT, "contacts.php": _PROJECT, "edit_project_customer.php": _PROJECT,
        "project_designs.php": {"id": None, "designid": None},
        "project_tasks.php": {"id": None, "taskid": None},
        "project_activity_logs.php": {"id": None, "email": "1"},
        "projects.php": {"action": ("1", "2"), "page": None},  # 1 pages through every project, 2 through the last search
        "download_document.php": {"project_id": None, "file_id": None},
        "download_photo.php": {"project_id": None, "photo_id": None, "file_id": None, "id": None},
    },
    "POST": {
        "dashboard_designs.php": {"action": "1", "multiple_location_id": ""},
        "ajax_get_project_design_data.php": {"design_id": None},
        "search.php": {"action": "1", **dict.fromkeys(
            ("number", "name", "milestone", "address", "city", "state", "description", "keywords", "billing_name",
             "purchase_order_number", "sp", "pm"))},
        "jq.customers.php": {"draw": "1", "start": None, "length": None, "search[value]": None, "search[regex]": "false"},
    },
}
_FILE = re.compile(r"\.(pdf|jpe?g|png|gif|bmp|tiff?|webp|heic|svg|ai|eps|cdr|dwg|dxf|3dm|psd|zip|docx?|xlsx?|pptx?|csv|txt|mp4|mov)$", re.I)


def _check_read(path: str, data: dict | None) -> None:
    parts = urllib.parse.urlsplit(path)
    page = parts.path.lstrip("/")
    query = dict(urllib.parse.parse_qsl(parts.query, keep_blank_values=True))
    if parts.netloc or parts.scheme:
        raise SquareCoilError(f"Refused: {path} is not a page of SquareCoil's.")
    if data is None and not query and _FILE.search(page) and ".php" not in page:
        return  # a file's own address
    allowed = READ_PAGES["POST" if data is not None else "GET"].get(page)
    sent = data if data is not None else query
    if allowed is None or (data is not None and query):
        raise SquareCoilError(f"Refused: {page or path} is not one of the pages this connector reads.")
    for key, value in sent.items():
        fixed = allowed.get(key)
        if key not in allowed or (fixed is not None and str(value) not in ((fixed,) if isinstance(fixed, str) else fixed)):
            raise SquareCoilError(f"Refused: {page} with {key}={value} is not a read this connector makes.")

class SquareCoil:
    """A signed-in session. Signs in on first use and again whenever SquareCoil sends it back to the login page."""

    def __init__(self, base_url: str = BASE_URL):
        self.base_url = base_url
        self._jar = http.cookiejar.CookieJar()
        self._opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self._jar))
        self._opener.addheaders = [("User-Agent", USER_AGENT)]
        self._signed_in = False

    def _request(self, path: str, data: dict | None = None) -> tuple[str, str]:
        url = urllib.parse.urljoin(self.base_url, path)
        body = urllib.parse.urlencode(data).encode() if data is not None else None
        try:
            with self._opener.open(url, body, timeout=TIMEOUT) as resp:
                charset = resp.headers.get_content_charset() or "utf-8"
                return resp.geturl(), resp.read().decode(charset, errors="replace")
        except OSError as e:
            raise SquareCoilError(f"Could not reach SquareCoil at {url}: {e}") from e

    @staticmethod
    def _is_login_page(url: str, page: str) -> bool:
        return "login.php" in url or ('name="password"' in page and 'name="username"' in page)

    def sign_in(self, username: str = "", password: str = "") -> None:
        """Signs in with the stored login, or with the one given (which `login` checks before storing it)."""
        given = bool(username)
        if not given:
            username, password = read_login()
        self._request("login.php")  # starts the PHP session
        url, page = self._request("login.php", {
            "action": "1", "username": username, "password": password,
            "latlong": "", "latlong_error": "", "latitude": "", "longitude": "",
        })
        if self._is_login_page(url, page):
            if given:
                raise SquareCoilError("SquareCoil did not accept that username and password.")
            raise SquareCoilError("SquareCoil did not accept the stored login. Sign in again with Install Connectors "
                                  "on Rhino's Alexandria Tools tab, or run `python squarecoil.py login`.")
        self._signed_in = True

    def fetch_file(self, path: str, most_bytes: int) -> tuple[str, str, bytes]:
        """One file's name, content type and bytes, from a download page or a file's own address."""
        _check_read(path, None)
        url = urllib.parse.urljoin(self.base_url, path)
        for attempt in (1, 2):
            if not self._signed_in:
                self.sign_in()
            try:
                with self._opener.open(url, timeout=TIMEOUT) as resp:
                    kind = resp.headers.get_content_type()
                    name = resp.headers.get_filename() or ""
                    body = resp.read(most_bytes + 1)
                    landed = resp.geturl()
            except OSError as e:
                raise SquareCoilError(f"Could not get the file from SquareCoil at {url}: {e}") from e
            if len(body) > most_bytes:
                raise SquareCoilError(f"That file is over {most_bytes // (1024 * 1024)} MB, so it was left in SquareCoil.")
            if "login.php" in landed or (kind == "text/html" and not name and self._is_login_page(landed, body[:20000].decode("utf-8", "replace"))):
                self._signed_in = False  # the session ran out: sign in and ask once more
                continue
            if kind == "text/html" and not name:
                raise SquareCoilError("SquareCoil answered with a page instead of a file: "
                                      + html_to_text(body[:2000].decode("utf-8", "replace"))[:200])
            return name, kind, body
        raise SquareCoilError("SquareCoil keeps sending this session back to its login page.")

    def get(self, path: str, data: dict | None = None) -> str:
        _check_read(path, data)
        if not self._signed_in:
            self.sign_in()
        url, page = self._request(path, data)
        if self._is_login_page(url, page):
            self.sign_in()
            url, page = self._request(path, data)
            if self._is_login_page(url, page):
                raise SquareCoilError("SquareCoil keeps sending this session back to its login page.")
        return page

    def design_requests(self) -> list[dict]:
        return parse_dashboard(self.get(DESIGNS_PATH, DESIGNS_FORM))

    def design_details(self, design_key: str) -> str:
        """The text of the pop-up the dashboard's (i) icon opens for one design request."""
        if not str(design_key).isdigit():
            raise SquareCoilError("design_key is SquareCoil's number for the design (5489), not its Design Id (250617-01).")
        fragment = self.get("ajax_get_project_design_data.php", {"design_id": str(design_key)})
        return html_to_text(fragment)


# --- the command line ---------------------------------------------------------------------------

def _print_table(rows: list[dict]) -> None:
    section = None
    for r in rows:
        if r["section"] != section:
            section = r["section"]
            print(f"\n{section}")
        marks = ("!" if r["flagged"] else " ") + ("*" if r["overdue"] else " ")
        print(f"{marks} {r['design_id']:<10} due {r['due_date']:<10}  {r['assigned_to']:<18} {r['description']}"
              + (f"  [{', '.join(r['type'])}]" if r["type"] else ""))
    print(f"\n{len(rows)} design requests.  * overdue   ! flagged")


LOGIN_SKIPPED = 3  # login's exit code when the username is left empty


def login(tries: int = 3) -> int:
    """Asks for the person's own SquareCoil login, checks it against SquareCoil and only then stores it.
    0 when stored, LOGIN_SKIPPED when the username is left empty, 1 when it never worked."""
    print("Sign in with your own SquareCoil login (the one for ariasigns.squarecoil.net). "
          "It is kept in Windows Credential Manager, never in a file. Leave the username empty to skip.")
    for attempt in range(tries):
        username = input("SquareCoil username: ").strip()
        if not username:
            print("Skipped: no SquareCoil login stored.")
            return LOGIN_SKIPPED
        password = getpass.getpass("SquareCoil password (not shown): ")
        try:
            SquareCoil().sign_in(username, password)
        except SquareCoilError as e:
            print(e)
            continue
        write_login(username, password)
        print(f"Signed in as {username}. The login is stored in Windows Credential Manager as {CREDENTIAL_TARGET}.")
        return 0
    print("No SquareCoil login stored.")
    return 1


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("login", help="store the SquareCoil login in Windows Credential Manager")
    d = sub.add_parser("designs", help="list the design requests")
    d.add_argument("--json", action="store_true")
    d.add_argument("--section", default="")
    d.add_argument("--assigned-to", default="")
    d.add_argument("--overdue", action="store_true")
    one = sub.add_parser("design", help="one design request's details")
    one.add_argument("design_key")
    p = sub.add_parser("parse", help="parse a saved dashboard page")
    p.add_argument("file")
    p.add_argument("--json", action="store_true")
    s = sub.add_parser("search", help="find projects by number, name, address, customer or description")
    s.add_argument("query", nargs="?", default="")
    for field in ("number", "name", "status", "address", "city", "state", "description", "billing-name",
                  "purchase-order", "salesperson", "project-manager"):
        s.add_argument(f"--{field}", default="")
    s.add_argument("--page", type=int, default=1)
    pr = sub.add_parser("project", help="one project, as JSON")
    pr.add_argument("project_number")
    pr.add_argument("--include", default="", help="comma-separated: designs, status, tasks, documents, photos, "
                                                  "production_files, contacts, activity, costs, or all")
    c = sub.add_parser("customers", help="find customers")
    c.add_argument("search", nargs="?", default="")
    dl = sub.add_parser("download", help="save one project file to this PC")
    dl.add_argument("url")
    dl.add_argument("--folder", default="")
    args = ap.parse_args(argv)

    try:
        if args.cmd == "login":
            return login()
        if args.cmd in ("search", "project", "customers", "download"):
            import projects
            sc = SquareCoil()
            if args.cmd == "search":
                fields = {k: v for k, v in vars(args).items() if k not in ("cmd", "query", "page") and v}
                out = projects.search(sc, args.query, args.page, **fields)
            elif args.cmd == "project":
                out = projects.read(sc, args.project_number, [t for t in args.include.split(",") if t.strip()])
            elif args.cmd == "customers":
                out = projects.customers(sc, args.search)
            else:
                out = projects.download(sc, args.url, args.folder)
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
            print(json.dumps(out, indent=1, ensure_ascii=False))
            return 0
        if args.cmd == "design":
            print(SquareCoil().design_details(args.design_key))
            return 0
        if args.cmd == "parse":
            with open(args.file, encoding="utf-8", errors="replace") as f:
                rows = parse_dashboard(f.read())
        else:
            rows = filter_designs(SquareCoil().design_requests(), section=args.section,
                                  assigned_to=args.assigned_to, overdue_only=args.overdue)
        if args.json:
            print(json.dumps(rows, indent=1, ensure_ascii=False))
        else:
            _print_table(rows)
        return 0
    except SquareCoilError as e:
        print(f"squarecoil: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    import squarecoil  # run as the module projects.py imports, so there is one SquareCoilError

    sys.exit(squarecoil.main())
