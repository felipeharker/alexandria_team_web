"""projects: read SquareCoil's projects, customers and files through a signed-in squarecoil.SquareCoil.

    search(sc, address="Gray")            the Existing Projects search, any of its fields
    read(sc, "260675", include=["all"])   one project: overview, then the tabs asked for
    customers(sc, "soto")                 the Records > Customers list
    download(sc, url)                     one project file, saved to this PC

SquareCoil has no API, so each function requests the page a browser would and reads its HTML.
Every parser here takes the page text and nothing else, so the tests run them on saved pages.
Only squarecoil.py talks to the network, and it refuses any page that isn't on its list of reads.
Python standard library only.
"""
from __future__ import annotations

import html
import json
import re
import urllib.parse
from datetime import datetime
from pathlib import Path

import squarecoil
from squarecoil import SquareCoilError, html_to_text

S = re.S | re.I
END = "<!-- End: Content -->"

# The Existing Projects search form: our name for a field, then SquareCoil's.
SEARCH_FIELDS = {
    "number": "number", "name": "name", "status": "milestone", "address": "address", "city": "city",
    "state": "state", "description": "description", "billing_name": "billing_name",
    "purchase_order": "purchase_order_number", "salesperson": "sp", "project_manager": "pm",
}
SEARCH_FORM = ("number", "name", "milestone", "address", "city", "state", "description", "keywords",
               "billing_name", "purchase_order_number", "sp", "pm")
STATUSES = ("All Pending", "Pending", "Pending Drawings", "Pending Estimates", "Pending Proposal Sent", "All Active",
            "Landlord Approval", "Permits", "Survey", "Manufacturing", "Shipping", "Install", "Service", "Invoice Notes",
            "Ready to be turned in", "Turned in for Billing", "Project Invoiced - Ready to Close", "On Hold",
            "Did Not Sell", "Closed")
# What a free-text query is tried against, in order.
QUERY_FIELDS = ("name", "address", "billing_name", "description", "city")

# The project's tabs that read() can add to the overview: our name, then SquareCoil's page.
TABS = {
    "designs": "project_designs.php", "status": "project_milestones.php", "tasks": "project_tasks.php",
    "documents": "project_documents.php", "photos": "project_site_photos.php",
    "production_files": "project_production_files.php", "contacts": "contacts.php",
    "activity": "project_activity_logs.php", "costs": "project_cost_to_date.php",
}
PAGE = 25  # projects to a page of search results
MOST_DESIGNS = 25  # each design and task is a page of its own
MOST_TASKS = 25

FILE_TYPES = ("pdf|jpe?g|png|gif|bmp|tiff?|webp|heic|svg|ai|eps|cdr|dwg|dxf|3dm|psd|zip|docx?|xlsx?|pptx?|csv|txt|"
              "mp4|mov")
DOWNLOAD = re.compile(r"^/?download_\w+\.php$", re.I)
FILE_PATH = re.compile(rf"\.(?:{FILE_TYPES})$", re.I)
SITE_FOLDERS = ("images/", "assets/", "vendor/", "img/", "js/", "css/", "fonts/")  # the site's own pictures
MOST_BYTES = 500 * 1024 * 1024


# --- small readers of HTML ----------------------------------------------------------------------

def _between(page: str, start: str, end: str) -> str:
    i = page.find(start)
    if i < 0:
        return ""
    j = page.find(end, i + len(start))
    return page[i + len(start): j if j >= 0 else len(page)]


def _text(fragment: str) -> str:
    return html_to_text(fragment)


def _line(fragment: str) -> str:
    return " ".join(_text(fragment).split())


def _rows(fragment: str) -> list[str]:
    return re.findall(r"<tr\b.*?</tr>", fragment, S)


def _cells(row: str) -> list[str]:
    return [_line(c) for c in re.findall(r"<t[dh]\b[^>]*>(.*?)</t[dh]>", row, S)]


def _links(fragment: str) -> list[tuple[str, str]]:
    return [(html.unescape(h), _line(t)) for h, t in
            re.findall(r"""<a\b[^>]*?\bhref\s*=\s*["']([^"']*)["'][^>]*>(.*?)</a>""", fragment, S)]


def _inputs(fragment: str) -> list[dict]:
    """Every <input> as its attributes, in page order."""
    out = []
    for tag in re.findall(r"<input\b[^>]*>", fragment, S):
        attrs = {k.lower(): html.unescape(v) for k, v in re.findall(r"""([\w-]+)\s*=\s*["']([^"']*)["']""", tag)}
        attrs["checked"] = bool(re.search(r"\bchecked\b", tag, re.I))
        out.append(attrs)
    return out


def _textarea(page: str, name: str) -> str:
    m = re.search(rf"""<textarea\b[^>]*\bname\s*=\s*["']{name}["'][^>]*>(.*?)</textarea>""", page, S)
    if not m:
        return ""
    return _text(html.unescape(m.group(1)))  # the scope is rich text, escaped inside the box


def _when(text: str) -> str:
    """SquareCoil's 11/23/2026 11:19 am as 2026-11-23 11:19; anything else comes back as it was."""
    text = " ".join(text.split())
    for fmt, out in (("%m/%d/%Y %I:%M %p", "%Y-%m-%d %H:%M"), ("%m/%d/%Y %I:%M:%S %p", "%Y-%m-%d %H:%M"),
                     ("%m/%d/%Y", "%Y-%m-%d")):
        try:
            return datetime.strptime(text, fmt).strftime(out)
        except ValueError:
            pass
    return text


def _url(href: str) -> str:
    return urllib.parse.urljoin(squarecoil.BASE_URL, href.lstrip("/"))


def _is_file(href: str) -> bool:
    parts = urllib.parse.urlsplit(href)
    if parts.netloc and parts.netloc != urllib.parse.urlsplit(squarecoil.BASE_URL).netloc:
        return False
    path = parts.path.lstrip("/")
    query = urllib.parse.parse_qs(parts.query)
    if DOWNLOAD.match(path):
        return "zip" not in query and "action" not in query and bool(query)
    return bool(FILE_PATH.search(path)) and not path.lower().startswith(SITE_FOLDERS)


def _files(fragment: str) -> list[dict]:
    """The files a fragment links to or shows: a name, the url download() takes, and the rest of its table row."""
    out, seen = [], set()

    def add(href: str, name: str, details: list[str]):
        href = html.unescape(href)
        if href in seen or not _is_file(href):
            return
        seen.add(href)
        name = name or Path(urllib.parse.urlsplit(href).path).name
        item = {"name": name, "url": _url(href)}
        details = [d for d in details if d and d != name and d.lower() not in ("edit", "delete", "move")]
        if details:
            item["details"] = details
        out.append(item)

    for row in _rows(fragment):
        for href, name in _links(row):
            add(href, name, _cells(row))
    for href, name in _links(fragment):  # files that aren't in a table
        add(href, name, [])
    for src in re.findall(r"""<img\b[^>]*?\bsrc\s*=\s*["']([^"']+)["']""", fragment, S):
        add(src, "", [])
    return out


# --- the project search ---------------------------------------------------------------------------

def parse_search(page: str) -> dict:
    """The Existing Projects page: how many projects match, how many pages of 25, and this page's rows."""
    if 'action = "search.php"' not in page and "Project Search" not in page:
        raise SquareCoilError("This isn't SquareCoil's project search page. SquareCoil may have changed it.")
    total = re.search(r"Matching Projects:\s*(\d+)", page)
    pages = re.search(r"totalPages:\s*(\d+)", page)
    rows = []
    for m in re.finditer(r'<tr class="clickableRowx" href="project\.php\?id=(\d+)".*?</tr>', page, S):
        cells = _cells(m.group(0))
        if len(cells) < 9:
            continue
        rows.append({
            "project_number": m.group(1), "name": cells[2], "address": cells[3].replace(" • ", ", "),
            "salesperson": cells[4], "status": cells[6], "created": _when(cells[8]),
            "favorite": 'class="fa fa-star"' in m.group(0),
            "url": _url(f"project.php?id={m.group(1)}"),
        })
    return {"matching": int(total.group(1)) if total else len(rows), "pages": int(pages.group(1)) if pages else 1,
            "projects": rows}


def search(sc, query: str = "", page: int = 1, **fields: str) -> dict:
    """Projects matching every field given (SEARCH_FIELDS), newest first, 25 to a page.

    `query` is for when the field isn't known: a project number is looked up as one, and anything else
    is tried against the name, site address, billing name, description and city, each match saying
    which it was found in."""
    unknown = set(fields) - set(SEARCH_FIELDS)
    if unknown:
        raise SquareCoilError(f"search has no field called {', '.join(sorted(unknown))}. It has: {', '.join(SEARCH_FIELDS)}.")
    fields = {k: str(v).strip() for k, v in fields.items() if str(v).strip()}
    query = query.strip()
    if not query and not fields:
        raise SquareCoilError("Give the search something to look for: a query, or one of " + ", ".join(SEARCH_FIELDS) + ".")

    def run(extra: dict) -> dict:
        form = dict.fromkeys(SEARCH_FORM, "")
        for ours, value in {**fields, **extra}.items():
            form[SEARCH_FIELDS[ours]] = value
        form["action"] = "1"
        first = sc.get("search.php", form)
        found = parse_search(first)
        if page > 1:  # SquareCoil keeps the search in the session, and its pager says where the next pages are
            pager = re.search(r"href:\s*'(projects\.php\?action=[12]&page=)\{\{number\}\}'", first)
            if not pager or page > found["pages"]:
                found["projects"] = []
            else:
                found["projects"] = parse_search(sc.get(f"{pager.group(1)}{int(page)}"))["projects"]
        return found

    def paged(extra: dict) -> dict:  # SquareCoil's pages overlap: each starts 25 on and runs to 100 rows
        found = run(extra)
        return {**found, "projects": found["projects"][:PAGE], "page": page}

    if not query:
        return paged({})
    if re.fullmatch(r"\d{4,6}(-\d+)?", query):
        return paged({"number": query.split("-")[0]})
    merged: dict[str, dict] = {}
    for field in QUERY_FIELDS:
        if field in fields:
            continue
        for row in run({field: query})["projects"]:
            merged.setdefault(row["project_number"], {**row, "matched_on": []})["matched_on"].append(field)
    rows = sorted(merged.values(), key=lambda r: r["project_number"], reverse=True)
    return {"matching": len(rows), "pages": 1, "page": 1, "projects": rows,
            "note": "A query shows the first 100 matches of each field. Search one field to page through more."}


# --- one project ----------------------------------------------------------------------------------

def parse_header(page: str) -> dict:
    """The band every project tab starts with: name, status, site address and open date."""
    if 'id="customer-name"' not in page:
        raise SquareCoilError("SquareCoil has no project with that number, or this login can't open it.")
    bar = _between(page, "<!-- Start: Green Bar -->", "<!-- End Green Bar -->")
    bands = [_text(b) for b in re.findall(r"<div\b[^>]*alert[^>]*>(.*?)</div>", bar, S)]
    status = bands[0].split("\n") if bands and bands[0] else []
    out = {
        "name": _line(_between(page, 'id="customer-name"', "</h1>").partition(">")[2]),
        "status": status[0] if status else "",
        "status_detail": status[1:],
        "alert": " ".join(" ".join(bands[1:]).split()),
        "site_address": _line(_between(page, 'glyphicon-map-marker"></span>', "</span>")).replace(" | ", ", "),
    }
    if not out["name"]:  # SquareCoil draws an empty project page for a number it doesn't have
        raise SquareCoilError("SquareCoil has no project with that number, or this login can't open it.")
    opened = re.search(r"Open Date:\s*([\d/]+)", page)
    out["open_date"] = _when(opened.group(1)) if opened else ""
    return out


def _person(fragment: str) -> dict:
    parts = [_line(p) for p in re.split(r"<br\s*/?>", fragment, flags=re.I)]
    if parts and not parts[0]:
        parts = parts[1:]
    parts += [""] * 3
    person = {"name": parts[0], "phone": parts[1], "email": parts[2]}
    return {k: v for k, v in person.items() if v}


def parse_overview(page: str) -> dict:
    """project.php, the Scope of Work tab: the header, the people, the important notes and the scope."""
    out = parse_header(page)
    people = re.search(r"Sales -\s*<br>\s*<strong>(.*?)</strong>\s*<br>\s*PM -\s*<br>\s*<strong>(.*?)</strong>", page, S)
    out["salesperson"] = _line(people.group(1)) if people else ""
    out["project_manager"] = _line(people.group(2)) if people else ""
    for label, body in re.findall(r"<address>\s*<strong>(.*?):</strong>(.*?)</address>", page, S):
        out[_line(label).lower().replace(" ", "_")] = _person(body)
    out["important_notes"] = _textarea(page, "notes")
    out["scope_of_work"] = _textarea(page, "description")
    updated = re.search(r"Last Updated on:\s*([^<]+)", page)
    out["scope_updated"] = _when(updated.group(1)) if updated else ""
    return out


def parse_billing(page: str) -> dict:
    """edit_project_customer.php, opened and never saved: the customer the project bills to."""
    if "Billing Information" not in page:
        return {}
    out: dict = {}
    for box in _inputs(page):
        if box.get("name") == "customer_id" and box["checked"]:
            out["customer_id"] = box.get("value", "")
    details = _between(page, "Customer Details", "New Contact Details")
    block, _, contact = details.partition("Contact Person")
    lines = _text(block).split("\n")
    if lines and lines[0]:
        out["customer"] = lines[0]
        out["billing_address"] = re.sub(r"(?<=\d)(?=[A-Z][a-z])", " ", ", ".join(lines[1:]))  # "77019United States"
    chosen = re.search(r"<option\b([^>]*\bselected\b[^>]*)>(.*?)</option>", contact, S)
    if chosen and _line(chosen.group(2)):
        person = {"name": _line(chosen.group(2))}
        attrs = dict(re.findall(r"""data-([\w-]+)\s*=\s*["']([^"']*)["']""", chosen.group(1)))
        for n in "1234":
            if attrs.get(f"value-{n}"):
                person[(attrs.get(f"label-{n}") or f"contact_{n}").lower()] = html.unescape(attrs[f"value-{n}"])
        out["billing_contact"] = person
    return out


def parse_design_list(page: str) -> list[dict]:
    """The designs a project has, oldest first, as the Design tab lists them."""
    found: dict[str, dict] = {}
    listing = _between(page, "new_design.php", "Total Design Hours")
    for key, label in re.findall(r'designid=(\d+)"[^>]*>(.*?)</a>', listing, S):
        label = _line(label)
        design = found.setdefault(key, {"design_key": key})
        design["date" if re.fullmatch(r"[\d/]+", label) else "design_id"] = _when(label)
    return list(found.values())


def parse_design(page: str) -> dict:
    """The design the Design tab has open: its fields, files and description (the request and its revisions)."""
    start = re.search(r">\s*Number:\s*</td>", page)
    if not start:
        return {}
    body = page[start.start(): page.find(END, start.start()) if END in page else len(page)]
    heading = re.search(r'panel-heading">\s*Description\s*</div>', body)
    fields, files_at = body, body.find("new_design_file.php")
    if files_at >= 0:
        fields = body[:files_at]
    cells = [c for row in _rows("<tr><td" + fields) for c in _cells(row)]
    out: dict = {}
    names = {"Number:": "design_id", "Type:": "type", "Assigned to:": "assigned_to", "Date Required:": "due_date",
             "Priority:": "priority", "Created By:": "created_by", "Hours:": "hours"}
    for i, cell in enumerate(cells[:-1]):
        if cell in names and not cells[i + 1].endswith(":"):
            out[names[cell]] = _when(cells[i + 1])
    state = re.search(r'alert alert-micro alert-primary">(.*?)</div>', fields, S)
    out["status"] = _line(state.group(1)) if state else ""
    out["files"] = _files(body[files_at: heading.start() if heading else len(body)]) if files_at >= 0 else []
    out["description"] = _text(body[heading.end():]) if heading else ""
    return out


def parse_task_list(page: str) -> list[dict]:
    found: dict[str, dict] = {}
    for key, label in re.findall(r'taskid=(\d+)"[^>]*>(.*?)</a>', _between(page, 'id="tasksTable"', "</table>"), S):
        label = _line(label)
        task = found.setdefault(key, {"task_key": key})
        task["date" if re.fullmatch(r"[\d/]+", label) else "subject"] = _when(label)
    return list(found.values())


def parse_task(page: str) -> dict:
    """The task the Tasks tab has open: when it was made, and its text (subject, people, message, replies)."""
    panel = _between(page, "Selected Task", END)
    if not panel:
        return {}
    made = re.search(r"\d\d/\d\d/\d{4} \d\d?:\d\d [ap]m", panel[:200])
    return {"created": _when(made.group(0)) if made else "", "text": _text(panel[panel.find("panel-body"):].partition(">")[2])}


def parse_status(page: str) -> list[dict]:
    """The Project Status tab: each milestone with its dates and its notes, newest note first as SquareCoil has them."""
    out = []
    tabs = re.findall(r'href="#tab-(\d+)"[^>]*>\s*([^<]+)', page)
    for n, (key, name) in enumerate(tabs):
        start = re.search(rf'id\s*=\s*"tab-{key}"', page)
        if not start:
            continue
        nxt = re.search(rf'id\s*=\s*"tab-{tabs[n + 1][0]}"', page) if n + 1 < len(tabs) else None
        pane = page[start.end(): nxt.start() if nxt else (page.find(END, start.end()) if END in page else len(page))]
        pane = re.sub(r"<[^>]*$", "", pane)  # the next pane's opening tag, cut in half
        form, _, notes = pane.partition("New Note</a>")
        stage: dict = {"milestone": _line(name)}
        for box in _inputs(form):
            kind, value = box.get("type", "text"), box.get("value", "").strip()
            if kind in ("hidden", "submit", "button") or box.get("name") in (None, "send_to", "subject"):
                continue
            if kind in ("radio", "checkbox"):
                if box["checked"] and box["name"] == "final_inspection":
                    stage["final_inspection_required"] = value == "1"
            elif value and value != "0":
                stage[box["name"]] = _when(value)
        stage["notes"] = []
        for note in notes.split('<span class="panel-title">')[1:]:
            head, _, body = note.partition("</span>")
            at, _, by = _line(head).partition(" -- ")
            stage["notes"].append({"at": _when(at), "by": by, "note": _text(body.partition('panel-body">')[2])})
        out.append(stage)
    return out


def parse_files(page: str, start: str, stop: str = END) -> dict:
    """A tab that lists files (Documents, Photos, Production Files): the files, or what the tab says instead."""
    body = _between(page, start, stop) if start in page else ""
    files = _files(body)
    if files:
        return {"files": files}
    says = [line for line in _text(body.partition(">")[2]).splitlines() if line.lower().startswith("no ")]
    return {"files": [], "says": " ".join(says) or "Nothing has been uploaded here."}


def parse_contacts(page: str) -> str:
    text = _text(_between(page, "Project Contacts", "Contact Directory"))
    return "" if text.strip().lower() == "no contacts found" else text


def parse_log(page: str, views: bool = False) -> list[dict]:
    """The Activity Log, newest first. Without `views` it leaves out who opened which tab, which is most of it."""
    out = []
    for row in _rows(_between(page, "sortable-table", END)):
        cells = _cells(row)
        if len(cells) < 3 or not re.match(r"\d\d/\d\d/\d{4}", cells[-1]):
            continue
        if not views and re.search(r"\b(View|Click)$", cells[0]):
            continue
        out.append({"at": _when(cells[-1]), "type": cells[0], "description": " | ".join(cells[1:-1])})
    return out


def parse_costs(page: str) -> list[str]:
    """Cost To Date: each line that has a number in it, estimated then actual."""
    out = []
    for row in _rows(_between(page, "Open Date:", END)):
        cells = [c for c in _cells(row) if c]
        if len(cells) < 2:
            continue
        figures = [c for c in cells[1:] if re.fullmatch(r"-?\$?[\d,]*\.?\d+", c)]
        if cells[0] == "TOTAL" or not figures or any(float(f.replace("$", "").replace(",", "")) for f in figures):
            out.append(" | ".join(cells))
    return out


def read(sc, project_number: str, include: list[str] | tuple = (), activity_views: bool = False) -> dict:
    """One project. Always the overview (name, status, site, people, billing customer, important notes,
    scope of work); `include` adds tabs by the names in TABS, or "all"."""
    number = str(project_number).strip().split("-")[0]
    if not number.isdigit():
        raise SquareCoilError("project_number is SquareCoil's number for the project, like 260675.")
    wanted = [t.strip().lower().replace(" ", "_") for t in include]
    if "all" in wanted:
        wanted = list(TABS)
    unknown = [t for t in wanted if t not in TABS]
    if unknown:
        raise SquareCoilError(f"A project has no part called {', '.join(unknown)}. It has: {', '.join(TABS)}, or all.")

    def tab(name: str, extra: str = "") -> str:
        return sc.get(f"{TABS[name]}?id={number}{extra}")

    out = {"project_number": number, "url": _url(f"project.php?id={number}")}
    out.update(parse_overview(sc.get(f"project.php?id={number}")))
    out["billing"] = parse_billing(sc.get(f"edit_project_customer.php?id={number}"))

    if "designs" in wanted:
        page = tab("designs")
        designs = parse_design_list(page)
        hours = re.search(r"Total Design Hours:\s*([\d.]+)", page)
        out["total_design_hours"] = hours.group(1) if hours else ""
        for design in designs[-MOST_DESIGNS:]:
            design.update(parse_design(tab("designs", f"&designid={design['design_key']}")))
            design["url"] = _url(f"project_designs.php?id={number}&designid={design['design_key']}")
        out["designs"] = designs
    if "status" in wanted:
        out["milestones"] = parse_status(tab("status"))
    if "tasks" in wanted:
        tasks = parse_task_list(tab("tasks"))
        for task in tasks[:MOST_TASKS]:
            task.update(parse_task(tab("tasks", f"&taskid={task['task_key']}")))
        out["tasks"] = tasks
    if "documents" in wanted:
        out["documents"] = parse_files(tab("documents"), "new_document_folder.php", "Delete Document")
    if "photos" in wanted:
        out["photos"] = parse_files(tab("photos"), "new_site_photo.php", "Delete Photo")
    if "production_files" in wanted:
        out["production_files"] = parse_files(tab("production_files"), "new_production_file_folder.php")
    if "contacts" in wanted:
        out["contacts"] = parse_contacts(tab("contacts"))
    if "activity" in wanted:
        out["activity"] = parse_log(tab("activity"), activity_views)
        out["emails_sent"] = parse_log(tab("activity", "&email=1"), True)
    if "costs" in wanted:
        out["costs"] = parse_costs(tab("costs"))
    return out


# --- customers --------------------------------------------------------------------------------------

def customers(sc, search_text: str = "", limit: int = 25) -> dict:
    """Records > Customers: the active customers whose name, address, city, zip or sales rep has the text."""
    limit = max(1, min(int(limit), 200))
    reply = sc.get("jq.customers.php", {"draw": "1", "start": "0", "length": str(limit),
                                        "search[value]": search_text.strip(), "search[regex]": "false"})
    try:
        data = json.loads(reply)
        rows = data["data"]
    except (ValueError, KeyError, TypeError) as e:
        raise SquareCoilError("SquareCoil's customer list didn't answer as it used to. SquareCoil may have changed it.") from e
    out = []
    for r in rows:
        out.append({"customer_id": str(r.get("local_id", "")), "name": r.get("name") or "",
                    "address": ", ".join(" ".join(str(r.get(k) or "").split()) for k in ("address", "city", "state", "zip")
                                         if str(r.get(k) or "").strip()),
                    "sales_rep": r.get("salesperson") or "", "one_time_only": str(r.get("onetime") or "") in ("1", "true")})
    return {"matching": int(data.get("recordsFiltered") or len(out)), "returned": len(out), "customers": out}


# --- files ------------------------------------------------------------------------------------------

def _safe_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    return name[:150] or "file"


def download(sc, url: str, folder: str = "") -> dict:
    """Save one file SquareCoil holds (a url from a project's documents, photos, production or design files)
    to this PC, in Downloads\\SquareCoil\\<project number> unless a folder is given."""
    full = _url(html.unescape(url.strip()))
    if not _is_file(full):
        raise SquareCoilError("That isn't a SquareCoil file. Pass a url from a project's documents, photos, "
                              "production files or design files.")
    parts = urllib.parse.urlsplit(full)
    query = urllib.parse.parse_qs(parts.query)
    project = next((v[0] for k, v in query.items() if k in ("project_id", "id") and v[0].isdigit()), "")
    name, kind, body = sc.fetch_file(parts.path.lstrip("/") + ("?" + parts.query if parts.query else ""), MOST_BYTES)
    name = _safe_name(name or Path(parts.path).name)
    target = Path(folder).expanduser() if folder else Path.home() / "Downloads" / "SquareCoil" / (project or "files")
    try:
        target.mkdir(parents=True, exist_ok=True)
        path = target / name
        path.write_bytes(body)
    except OSError as e:
        raise SquareCoilError(f"Could not save the file in {target}: {e}") from e
    return {"path": str(path), "name": name, "bytes": len(body), "content_type": kind}
