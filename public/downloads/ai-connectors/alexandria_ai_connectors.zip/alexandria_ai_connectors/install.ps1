<#
Alexandria: the connectors (MCP servers) for Rhino, CorelDRAW and SquareCoil, on this Windows PC.

    powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1 [-Only rhino,coreldraw,squarecoil]
                                                                    [-Check] [-Status] [-AskLogin] [-Uninstall] [-NoPause]

Claude and Grok get the connectors from Alexandria's plugins, which the team's organization in each
has. A plugin only starts a server: this puts the servers, and what they need, on the PC.

Alexandria Setup and Install Connectors in Rhino run this, and so does "Install AI Connectors.cmd"
beside it. Run it again at any time: it only does what is still missing, and updates what it installed.

Rhino      McNeel's own Rhino-MCP-Platform package, installed into Rhino 8 with Rhino's package
           manager (Yak) from McNeel's server. A small launcher, rhino-mcp.cmd, starts whichever
           version of it is installed, so the connector survives the package's updates.
CorelDRAW  The coreldraw-live server in coreldraw/ beside this script, copied to this PC with
           its own Python (uv installs both, and the pinned packages in requirements.txt).
           Only on a PC that has CorelDRAW.
SquareCoil The squarecoil server in squarecoil/ beside this script (Python standard library only),
           copied to this PC with its own Python from uv. It reads Aria's design requests and projects with
           the person's own SquareCoil login, which it asks for once, checks against SquareCoil and
           keeps in Windows Credential Manager. Leaving the username empty skips it, and -Check
           stops asking; Install Connectors in Rhino (-AskLogin) asks again.
Old        Up to 2.21 this also added each connector to Claude Desktop's config and Claude Code's.
entries    With the plugins those entries would show each connector twice, so they are taken out:
           a config is backed up, our entries are cut from its text, and the result is checked
           before it replaces the file. An entry of the same name that somebody else set up stays.

Everything this installs lives in %USERPROFILE%\.alexandria\claude_connectors, the folder the plugins'
commands name (not AppData: the Claude Desktop app from the Microsoft Store sees its own private
copy of AppData).

-Only       Just these connectors, by key: rhino, coreldraw, squarecoil (comma-separated). All by default.
-Check      Changes nothing. Exit code 0 when there is nothing to do, 1 when there is.
-Status     Changes nothing. One line per connector, key<TAB>state<TAB>what: state is ok, todo,
            absent (its program isn't on this PC), skipped or failed. Install Connectors reads it.
-AskLogin   Asks for the SquareCoil login even after it was skipped.
-Uninstall  Takes any old entries out of the Claude configs and the SquareCoil login out of
            Credential Manager, and deletes the folder. The Rhino package stays: uninstall it in
            Rhino's Package Manager. The plugins stay too, and say the server is missing.
-NoPause    Doesn't wait for a key at the end.
The rest are for testing: -InstallHome, -DesktopConfig, -SkipDesktop, -SkipClaudeCode, -Source.

Keep this file ASCII: Windows PowerShell 5.1 reads a script without a BOM as ANSI.
#>
[CmdletBinding()]
param(
    [string[]]$Only,
    [switch]$Check,
    [switch]$Status,
    [switch]$AskLogin,
    [switch]$Uninstall,
    [switch]$NoPause,
    [string]$InstallHome,
    [string[]]$DesktopConfig,
    [switch]$SkipDesktop,
    [switch]$SkipClaudeCode,
    [string]$Source
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2

$RHINO_NAME = 'rhino-mcp-platform'
$COREL_NAME = 'coreldraw-live'
$SQUARECOIL_NAME = 'squarecoil'
$SQUARECOIL_TARGET = 'alexandria/squarecoil/ariasigns'   # its login in Windows Credential Manager, as squarecoil.py names it
$LOGIN_SKIPPED = 3                                         # squarecoil.py login's exit code when the username is left empty
$RHINO_PACKAGE = 'Rhino-MCP-Platform'
$PYTHON_VERSION = '3.12'

if ($Status) { $Check = $true }   # -Status is -Check, told per connector
if (-not $InstallHome) { $InstallHome = $env:ALEXANDRIA_CONNECTORS_HOME }
if (-not $InstallHome) { $InstallHome = Join-Path $env:USERPROFILE '.alexandria\claude_connectors' }
$InstallHome = [IO.Path]::GetFullPath($InstallHome)
if (-not $Source) { $Source = $PSScriptRoot }
$LogFile = Join-Path $InstallHome 'install.log'

$script:Pending = New-Object System.Collections.ArrayList   # what -Check found to do
$script:Failed = New-Object System.Collections.ArrayList
$script:Changed = $false
$script:Note = $null       # why a connector was left out: set by Install-* with NoteKind absent, skipped or failed
$script:NoteKind = $null

Add-Type -AssemblyName System.Web.Extensions
$script:Json = New-Object System.Web.Script.Serialization.JavaScriptSerializer
$script:Json.MaxJsonLength = [int]::MaxValue
$script:Json.RecursionLimit = 500


# ------------------------------------------------------------------ output
function Log([string]$text) {
    if ($Check -or $Uninstall) { return }
    try {
        if (-not (Test-Path $InstallHome)) { New-Item -ItemType Directory -Force $InstallHome | Out-Null }
        Add-Content -LiteralPath $LogFile -Value ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $text) -Encoding UTF8
    } catch { }
}

function Say([string]$text) {
    if (-not $Check) { Write-Host $text }
    Log $text
}

function Need([string]$what) {
    # In -Check, notes that something is still to do. Returns $true when the caller should do it now.
    if ($Check) { if (-not $script:Pending.Contains($what)) { [void]$script:Pending.Add($what) }; return $false }
    return $true
}

function Fail([string]$what) {
    [void]$script:Failed.Add($what)
    Say ("  ! " + $what)
}

function Quote-Arg([string]$arg) {
    if ($arg -match '[\s"]') { return '"' + $arg + '"' }
    return $arg
}

function Run-Tool([string]$exe, [string[]]$arguments, [hashtable]$environment) {
    # Runs a program without a window of its own, its output going to the log. Returns its exit code.
    $out = [IO.Path]::GetTempFileName()
    $err = [IO.Path]::GetTempFileName()
    $saved = @{}
    try {
        if ($environment) {
            foreach ($key in $environment.Keys) {
                $saved[$key] = [Environment]::GetEnvironmentVariable($key, 'Process')
                [Environment]::SetEnvironmentVariable($key, $environment[$key], 'Process')
            }
        }
        Log ("run: " + $exe + " " + ($arguments -join ' '))
        $line = ($arguments | ForEach-Object { Quote-Arg $_ }) -join ' '
        $process = Start-Process -FilePath $exe -ArgumentList $line -NoNewWindow -Wait -PassThru `
            -RedirectStandardOutput $out -RedirectStandardError $err
        foreach ($file in $out, $err) {
            $text = [IO.File]::ReadAllText($file).Trim()
            if ($text) { Log $text }
        }
        return $process.ExitCode
    } finally {
        foreach ($key in $saved.Keys) { [Environment]::SetEnvironmentVariable($key, $saved[$key], 'Process') }
        Remove-Item -LiteralPath $out, $err -ErrorAction SilentlyContinue
    }
}

function Get-Utf8Bytes([string]$text, [bool]$bom) {
    $body = (New-Object System.Text.UTF8Encoding($false)).GetBytes($text)
    if (-not $bom) { return ,$body }
    $bytes = New-Object byte[] ($body.Length + 3)
    $bytes[0] = 0xEF; $bytes[1] = 0xBB; $bytes[2] = 0xBF
    [Array]::Copy($body, 0, $bytes, 3, $body.Length)
    return ,$bytes
}

function Write-Atomic([string]$path, [byte[]]$bytes) {
    $temp = $path + '.alexandria-new'
    [IO.File]::WriteAllBytes($temp, $bytes)
    if (Test-Path -LiteralPath $path) {
        try { [IO.File]::Replace($temp, $path, $null) }
        catch { Copy-Item -LiteralPath $temp -Destination $path -Force; Remove-Item -LiteralPath $temp -Force }
    } else {
        Move-Item -LiteralPath $temp -Destination $path
    }
}


# ------------------------------------------------------------------ JSON, read in place
# A config is never parsed and written back whole: that would reorder or reformat what other
# programs keep in it. These find where a member sits in the text, so only that part changes.
function Skip-Ws([string]$t, [int]$i) {
    while ($i -lt $t.Length -and " `t`r`n".IndexOf($t[$i]) -ge 0) { $i++ }
    return $i
}

function Skip-String([string]$t, [int]$i) {
    # $t[$i] is the opening quote. Returns the index after the closing one.
    $from = $i + 1
    while ($true) {
        $quote = $t.IndexOf('"', $from)
        if ($quote -lt 0) { throw 'a string never ends' }
        $slashes = 0
        $k = $quote - 1
        while ($k -ge $from -and $t[$k] -eq '\') { $slashes++; $k-- }
        if ($slashes % 2 -eq 0) { return $quote + 1 }
        $from = $quote + 1
    }
}

function Skip-Value([string]$t, [int]$i) {
    # Returns the index after the value that starts at $i.
    $c = $t[$i]
    if ($c -eq '"') { return (Skip-String $t $i) }
    if ($c -eq '{' -or $c -eq '[') {
        $marks = '"{}[]'.ToCharArray()
        $depth = 0
        while ($true) {
            $i = $t.IndexOfAny($marks, $i)
            if ($i -lt 0) { throw 'an object never ends' }
            $c = $t[$i]
            if ($c -eq '"') { $i = Skip-String $t $i; continue }
            if ($c -eq '{' -or $c -eq '[') { $depth++ } else { $depth--; if ($depth -eq 0) { return $i + 1 } }
            $i++
        }
    }
    while ($i -lt $t.Length -and ",}] `t`r`n".IndexOf($t[$i]) -lt 0) { $i++ }
    return $i
}

function Get-Members([string]$t, [int]$open) {
    # The members of the object whose "{" is at $open, in order, each with where its key and value sit.
    $members = New-Object System.Collections.ArrayList
    $i = Skip-Ws $t ($open + 1)
    while ($t[$i] -ne '}') {
        if ($t[$i] -ne '"') { throw "expected a name at character $i" }
        $keyStart = $i
        $i = Skip-String $t $i
        $name = [string]$script:Json.DeserializeObject($t.Substring($keyStart, $i - $keyStart))
        $i = Skip-Ws $t $i
        if ($t[$i] -ne ':') { throw "expected ':' at character $i" }
        $valueStart = Skip-Ws $t ($i + 1)
        $i = Skip-Value $t $valueStart
        [void]$members.Add((New-Object psobject -Property @{
            Name = $name; KeyStart = $keyStart; ValueStart = $valueStart; ValueEnd = $i }))
        $i = Skip-Ws $t $i
        if ($t[$i] -eq ',') { $i = Skip-Ws $t ($i + 1) }
        elseif ($t[$i] -ne '}') { throw "expected ',' or '}' at character $i" }
    }
    return (New-Object psobject -Property @{ Members = $members; Open = $open; Close = $i })
}

function Find-Member($object, [string]$name) {
    foreach ($member in $object.Members) { if ($member.Name -ceq $name) { return $member } }
    return $null
}

function Get-ServerBlock([string]$t) {
    # The top object and its "mcpServers" object ($null when there is none).
    $open = Skip-Ws $t 0
    if ($open -ge $t.Length -or $t[$open] -ne '{') { throw 'the file is not a JSON object' }
    $top = Get-Members $t $open
    $member = Find-Member $top 'mcpServers'
    $servers = $null
    if ($member) {
        if ($t[$member.ValueStart] -ne '{') { throw '"mcpServers" is not an object' }
        $servers = Get-Members $t $member.ValueStart
    }
    return (New-Object psobject -Property @{ Top = $top; Servers = $servers })
}

function Test-Ours($existing) {
    # Whether an entry runs something from our folder, so it is ours to update or remove.
    if (-not ($existing -is [System.Collections.IDictionary])) { return $false }
    $words = @()
    if ($existing.ContainsKey('command')) { $words += [string]$existing['command'] }
    if ($existing.ContainsKey('args') -and $existing['args']) { $words += @($existing['args'] | ForEach-Object { [string]$_ }) }
    foreach ($word in $words) {
        if ($word.StartsWith($InstallHome + '\', [StringComparison]::OrdinalIgnoreCase)) { return $true }
    }
    return $false
}

function Read-Text([string]$path) {
    # A config's text, with whether it starts with a BOM.
    $bytes = [IO.File]::ReadAllBytes($path)
    $bom = $bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF
    $text = (New-Object System.Text.UTF8Encoding($false, $true)).GetString($bytes)   # throws on bytes that are not UTF-8
    if ($bom) { $text = $text.Substring(1) }
    return (New-Object psobject -Property @{ Text = $text; Bom = $bom })
}

function Remove-Servers([string]$text, [string[]]$names) {
    # The config text without those of the named entries that are ours.
    foreach ($name in $names) {
        $block = Get-ServerBlock $text
        if (-not $block.Servers) { return $text }
        $members = $block.Servers.Members
        $index = -1
        for ($i = 0; $i -lt $members.Count; $i++) { if ($members[$i].Name -ceq $name) { $index = $i } }
        if ($index -lt 0) { continue }
        $member = $members[$index]
        $existing = $script:Json.DeserializeObject($text.Substring($member.ValueStart, $member.ValueEnd - $member.ValueStart))
        if (-not (Test-Ours $existing)) { continue }
        if ($index + 1 -lt $members.Count) { $text = $text.Substring(0, $member.KeyStart) + $text.Substring($members[$index + 1].KeyStart) }
        elseif ($index -gt 0) { $text = $text.Substring(0, $members[$index - 1].ValueEnd) + $text.Substring($member.ValueEnd) }
        else { $text = $text.Substring(0, $block.Servers.Open + 1) + $text.Substring($block.Servers.Close) }
    }
    return $text
}

function Save-Config([string]$path, [string]$old, [string]$new, [bool]$bom, [string[]]$removed) {
    # Checks the new text is sound and has every server the old one had but those removed, backs the old file up, then writes.
    [void]$script:Json.DeserializeObject($new)
    $before = @(); $after = @()
    $oldBlock = Get-ServerBlock $old
    if ($oldBlock.Servers) { $before = @($oldBlock.Servers.Members | ForEach-Object { $_.Name }) }
    $newBlock = Get-ServerBlock $new
    if ($newBlock.Servers) { $after = @($newBlock.Servers.Members | ForEach-Object { $_.Name }) }
    foreach ($name in $before) {
        if (($removed -cnotcontains $name) -and ($after -cnotcontains $name)) { throw "the new config would lose `"$name`"" }
    }
    foreach ($name in $removed) { if ($after -ccontains $name) { throw "`"$name`" is still in the new config" } }
    $backup = '{0}.alexandria-{1}.bak' -f $path, (Get-Date -Format 'yyyyMMdd-HHmmss')
    Copy-Item -LiteralPath $path -Destination $backup -Force
    Log ("backup: " + $backup)
    Write-Atomic $path (Get-Utf8Bytes $new $bom)
}


# ------------------------------------------------------------------ Rhino
function Get-Yak {
    foreach ($version in '8', '9') {
        $folders = @()
        try {
            $key = Get-ItemProperty -Path "HKLM:\SOFTWARE\McNeel\Rhinoceros\$version.0\Install" -ErrorAction Stop
            foreach ($name in 'Path', 'InstallPath') {
                if ($key.PSObject.Properties[$name] -and $key.$name) { $folders += [string]$key.$name }
            }
        } catch { }
        $folders += (Join-Path $env:ProgramFiles "Rhino $version\System")
        foreach ($folder in $folders) {
            foreach ($candidate in (Join-Path $folder 'Yak.exe'), (Join-Path $folder 'System\Yak.exe')) {
                if (Test-Path -LiteralPath $candidate) { return (New-Object psobject -Property @{ Version = $version; Path = $candidate }) }
            }
        }
    }
    return $null
}

function Get-Router {
    # The router of the installed Rhino-MCP-Platform package, as rhino-mcp.cmd finds it.
    $arch = 'win-x64'
    if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { $arch = 'win-arm64' }
    foreach ($version in '8.0', '9.0') {
        $package = Join-Path $env:APPDATA "McNeel\Rhinoceros\packages\$version\$RHINO_PACKAGE"
        $manifest = Join-Path $package 'manifest.txt'
        if (-not (Test-Path -LiteralPath $manifest)) { continue }
        $installed = ([string](Get-Content -LiteralPath $manifest -TotalCount 1)).Trim()
        $router = Join-Path $package "$installed\router\$arch\rhino-mcp-router.exe"
        if (Test-Path -LiteralPath $router) { return $router }
    }
    return $null
}

$LAUNCHER_TEXT = @'
@echo off
rem Alexandria: starts the MCP router of whichever Rhino-MCP-Platform package is installed.
rem Written by Alexandria's install.ps1. The rhino-mcp-platform plugin runs this; it isn't for double-clicking.
setlocal
set "ARCH=win-x64"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "ARCH=win-arm64"
set "PKG=%APPDATA%\McNeel\Rhinoceros\packages\8.0\Rhino-MCP-Platform"
if not exist "%PKG%\manifest.txt" set "PKG=%APPDATA%\McNeel\Rhinoceros\packages\9.0\Rhino-MCP-Platform"
if not exist "%PKG%\manifest.txt" goto missing
set /p VER=<"%PKG%\manifest.txt"
if not exist "%PKG%\%VER%\router\%ARCH%\rhino-mcp-router.exe" goto missing
"%PKG%\%VER%\router\%ARCH%\rhino-mcp-router.exe" %*
exit /b %ERRORLEVEL%
:missing
echo Rhino-MCP-Platform is not installed in Rhino. Run AlexandriaSetup in Rhino, or install it from Rhino's Package Manager. 1>&2
exit /b 1
'@

function Install-Rhino {
    # Returns $true when the package and its launcher are in place, $null when this PC has no Rhino for it.
    $yak = Get-Yak
    $router = Get-Router
    if (-not $router) {
        if (-not $yak) {
            $script:NoteKind = 'absent'; $script:Note = 'Rhino 8 is not on this PC'
            Say '  Rhino 8 is not on this PC, so the Rhino connector is skipped.'; return $null
        }
        $stamp = Join-Path $InstallHome 'rhino-package.failed'
        $yakVersion = (Get-Item -LiteralPath $yak.Path).VersionInfo.FileVersion
        if ($Check -and (Test-Path -LiteralPath $stamp) -and ((Get-Content -LiteralPath $stamp -TotalCount 1) -eq $yakVersion)) {
            $script:NoteKind = 'failed'; $script:Note = "Rhino's package manager could not install $RHINO_PACKAGE last time"
            return $null   # it failed with this Rhino already: updating Rhino, or running this by hand, tries again
        }
        if (-not (Need "install the $RHINO_PACKAGE package in Rhino $($yak.Version)")) { return $null }
        Say "  Installing McNeel's $RHINO_PACKAGE package in Rhino $($yak.Version)..."
        $code = Run-Tool $yak.Path @('install', $RHINO_PACKAGE) $null
        $router = Get-Router
        if (-not $router) {
            Set-Content -LiteralPath $stamp -Value $yakVersion -Encoding ASCII
            Fail "Rhino's package manager could not install $RHINO_PACKAGE (exit code $code). It needs Rhino 8.19 or later and the internet. See $LogFile."
            return $null
        }
        Remove-Item -LiteralPath $stamp -ErrorAction SilentlyContinue
        $script:Changed = $true
        Say '  Installed. Restart Rhino to load it.'
    } else {
        Say "  The $RHINO_PACKAGE package is installed."
    }
    $launcher = Join-Path $InstallHome 'rhino-mcp.cmd'
    $wanted = $LAUNCHER_TEXT -replace "`r?`n", "`r`n"
    $current = $null
    if (Test-Path -LiteralPath $launcher) { $current = [IO.File]::ReadAllText($launcher) }
    if ($current -cne $wanted) {
        if (Need 'write the Rhino launcher') {
            [IO.File]::WriteAllText($launcher, $wanted, (New-Object System.Text.ASCIIEncoding))
            $script:Changed = $true
        }
    }
    return $true
}


# ------------------------------------------------------------------ CorelDRAW
function Get-FolderHash([string]$folder) {
    $sha = [Security.Cryptography.SHA256]::Create()
    $lines = New-Object System.Collections.ArrayList
    $files = Get-ChildItem -LiteralPath $folder -Recurse -File | Where-Object {
        $_.FullName -notmatch '\\(\.venv|logs|__pycache__)\\' -and $_.Name -ne 'source.sha256' } | Sort-Object FullName
    foreach ($file in $files) {
        $hash = [BitConverter]::ToString($sha.ComputeHash([IO.File]::ReadAllBytes($file.FullName))) -replace '-', ''
        [void]$lines.Add($file.FullName.Substring($folder.Length).TrimStart('\').ToLowerInvariant() + ' ' + $hash)
    }
    $all = [Text.Encoding]::UTF8.GetBytes(($lines -join "`n"))
    return ([BitConverter]::ToString($sha.ComputeHash($all)) -replace '-', '')
}

function Get-Uv {
    $command = Get-Command uv.exe -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    foreach ($candidate in (Join-Path $env:USERPROFILE '.local\bin\uv.exe'), (Join-Path $InstallHome 'uv\uv.exe')) {
        if (Test-Path -LiteralPath $candidate) { return $candidate }
    }
    return $null
}

function Install-Uv {
    # uv, Astral's Python installer, into our own folder: no PATH or profile changes.
    $folder = Join-Path $InstallHome 'uv'
    Say '  Downloading uv, which installs Python and its packages...'
    $bootstrap = "[Net.ServicePointManager]::SecurityProtocol = 'Tls12'; " +
              "`$env:UV_UNMANAGED_INSTALL = '$($folder -replace "'", "''")'; " +
              "Invoke-RestMethod https://astral.sh/uv/install.ps1 | Invoke-Expression"
    $code = Run-Tool 'powershell.exe' @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', $bootstrap) $null
    $uv = Join-Path $folder 'uv.exe'
    if (Test-Path -LiteralPath $uv) { return $uv }
    Log "uv install exit code $code"
    return $null
}

function Get-UvEnvironment {
    # Pythons uv installs go in our own folder, shared by the servers that need one.
    return @{ UV_PYTHON_INSTALL_DIR = (Join-Path $InstallHome 'python'); UV_PYTHON_PREFERENCE = 'only-managed'
              UV_LINK_MODE = 'copy'; UV_NO_PROGRESS = '1' }
}

function Install-Corel {
    # Returns $true when the server is in place, $null when this PC has no CorelDRAW or the install failed.
    if (-not (Test-Path 'Registry::HKEY_CLASSES_ROOT\CorelDRAW.Application')) {
        $script:NoteKind = 'absent'; $script:Note = 'CorelDRAW is not on this PC'
        Say '  CorelDRAW is not on this PC, so the CorelDRAW connector is skipped.'
        return $null
    }
    $from = Join-Path $Source 'coreldraw'
    $to = Join-Path $InstallHome 'coreldraw'
    $python = Join-Path $to '.venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath (Join-Path $from 'server\server.py'))) {
        Fail "The CorelDRAW server is missing from $from."
        return $null
    }

    # the server's files
    $wanted = Get-FolderHash $from
    $stamp = Join-Path $to 'source.sha256'
    $have = $null
    if (Test-Path -LiteralPath $stamp) { $have = ([string](Get-Content -LiteralPath $stamp -TotalCount 1)).Trim() }
    if ($have -ne $wanted) {
        if (-not (Need 'copy the CorelDRAW server to this PC')) { return $null }
        Say '  Copying the CorelDRAW server...'
        New-Item -ItemType Directory -Force $to | Out-Null
        Remove-Item -LiteralPath (Join-Path $to 'server') -Recurse -Force -ErrorAction SilentlyContinue
        foreach ($item in Get-ChildItem -LiteralPath $from -Force) {
            if ($item.Name -in '.venv', 'logs', '__pycache__') { continue }
            Copy-Item -LiteralPath $item.FullName -Destination $to -Recurse -Force
        }
        Set-Content -LiteralPath $stamp -Value $wanted -Encoding ASCII
        $script:Changed = $true
    }

    # its Python and packages
    $requirements = Join-Path $to 'requirements.txt'
    $wanted = (Get-FileHash -LiteralPath (Join-Path $from 'requirements.txt') -Algorithm SHA256).Hash
    $stamp = Join-Path $to '.venv\requirements.sha256'
    $have = $null
    if (Test-Path -LiteralPath $stamp) { $have = ([string](Get-Content -LiteralPath $stamp -TotalCount 1)).Trim() }
    if ($have -ne $wanted -or -not (Test-Path -LiteralPath $python)) {
        if (-not (Need 'install Python and the packages the CorelDRAW server needs')) { return $null }
        $uv = Get-Uv
        if (-not $uv) { $uv = Install-Uv }
        if (-not $uv) { Fail "uv could not be downloaded from astral.sh. Check the internet connection. See $LogFile."; return $null }
        $environment = Get-UvEnvironment
        Say "  Installing Python $PYTHON_VERSION and the server's packages. This takes a minute or two the first time..."
        $venv = Join-Path $to '.venv'
        if (Test-Path -LiteralPath $venv) {
            try { Remove-Item -LiteralPath $venv -Recurse -Force }
            catch { Fail 'The CorelDRAW server is running, so it could not be updated. Quit Claude, then run this again.'; return $null }
        }
        $code = Run-Tool $uv @('venv', $venv, '--python', $PYTHON_VERSION) $environment
        if ($code -eq 0) { $code = Run-Tool $uv @('pip', 'install', '--python', $python, '--require-hashes', '-r', $requirements) $environment }
        if ($code -eq 0) { $code = Run-Tool $python @('-c', 'import fastmcp, win32com.client, pythoncom, pydantic_settings, loguru, dotenv') $null }
        if ($code -ne 0) {
            Fail "Python or the CorelDRAW server's packages could not be installed (exit code $code). See $LogFile."
            return $null
        }
        Set-Content -LiteralPath $stamp -Value $wanted -Encoding ASCII
        $script:Changed = $true
    }
    Say '  The CorelDRAW server is installed.'
    return $true
}


# ------------------------------------------------------------------ SquareCoil
function Get-SquareCoilUser {
    # The SquareCoil username stored in Credential Manager, or $null when there is none.
    $lines = @(& cmdkey.exe "/list:$SQUARECOIL_TARGET" 2>$null)
    if (-not ($lines -match [regex]::Escape($SQUARECOIL_TARGET))) { return $null }
    foreach ($line in $lines) { if ($line -match '^\s*User:\s*(.+?)\s*$') { return $Matches[1] } }
    return '(stored)'
}

function Install-SquareCoil {
    # Returns $true when the server is in place and signed in, $null when it is skipped or the install failed.
    $from = Join-Path $Source 'squarecoil'
    $to = Join-Path $InstallHome 'squarecoil'
    $python = Join-Path $to '.venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath (Join-Path $from 'server.py'))) { Fail "The SquareCoil server is missing from $from."; return $null }
    $skipped = Join-Path $InstallHome 'squarecoil.skipped'
    $user = Get-SquareCoilUser
    if (-not $user -and (Test-Path -LiteralPath $skipped) -and -not $AskLogin) {
        $script:NoteKind = 'skipped'; $script:Note = 'no SquareCoil login: it was skipped'
        Say '  No SquareCoil login, so the SquareCoil connector is skipped. Install Connectors in Rhino asks for it again.'
        return $null
    }

    # the server's files
    $wanted = Get-FolderHash $from
    $stamp = Join-Path $to 'source.sha256'
    $have = $null
    if (Test-Path -LiteralPath $stamp) { $have = ([string](Get-Content -LiteralPath $stamp -TotalCount 1)).Trim() }
    if ($have -ne $wanted) {
        if (-not (Need 'copy the SquareCoil server to this PC')) { return $null }
        Say '  Copying the SquareCoil server...'
        New-Item -ItemType Directory -Force $to | Out-Null
        foreach ($item in Get-ChildItem -LiteralPath $from -Force) {
            if ($item.Name -in '.venv', 'logs', '__pycache__') { continue }
            Copy-Item -LiteralPath $item.FullName -Destination $to -Recurse -Force
        }
        Set-Content -LiteralPath $stamp -Value $wanted -Encoding ASCII
        $script:Changed = $true
    }

    # its Python: the standard library is all it needs
    if (-not (Test-Path -LiteralPath $python)) {
        if (-not (Need 'install Python for the SquareCoil server')) { return $null }
        $uv = Get-Uv
        if (-not $uv) { $uv = Install-Uv }
        if (-not $uv) { Fail "uv could not be downloaded from astral.sh. Check the internet connection. See $LogFile."; return $null }
        Say "  Installing Python $PYTHON_VERSION for the SquareCoil server..."
        $code = Run-Tool $uv @('venv', (Join-Path $to '.venv'), '--python', $PYTHON_VERSION) (Get-UvEnvironment)
        if ($code -ne 0 -or -not (Test-Path -LiteralPath $python)) {
            Fail "Python could not be installed for the SquareCoil server (exit code $code). See $LogFile."
            return $null
        }
        $script:Changed = $true
    }

    # the person's own login, asked for here, in this window
    if (-not $user) {
        if (-not (Need 'sign in to SquareCoil')) { return $null }
        Write-Host ''
        # in this window, with nothing redirected, so it can ask; its output stays out of what this returns
        $login = Start-Process -FilePath $python -ArgumentList ('-I "' + (Join-Path $to 'squarecoil.py') + '" login') `
            -NoNewWindow -Wait -PassThru
        $code = $login.ExitCode
        Write-Host ''
        if ($code -eq $LOGIN_SKIPPED) {
            Set-Content -LiteralPath $skipped -Value (Get-Date -Format 'yyyy-MM-dd') -Encoding ASCII
            $script:NoteKind = 'skipped'; $script:Note = 'no SquareCoil login: it was skipped'
            Say '  SquareCoil skipped. Install Connectors in Rhino asks for the login again.'
            return $null
        }
        $user = Get-SquareCoilUser
        if ($code -ne 0 -or -not $user) { Fail 'No SquareCoil login was stored, so the SquareCoil connector cannot sign in.'; return $null }
        $script:Changed = $true
    }
    Remove-Item -LiteralPath $skipped -ErrorAction SilentlyContinue
    Say "  The SquareCoil server is installed, signed in as $user."
    return $true
}


# ------------------------------------------------------------------ old Claude entries
# Up to 2.21 this installer also added each connector to Claude Desktop's config and Claude Code's.
# Alexandria's plugins start the servers now, so an entry left there would show its connector twice.
# Only our own are taken out: an entry that runs something from our folder.
function Get-DesktopConfigs {
    # Every Claude Desktop config on this PC. The Microsoft Store build keeps its own under Packages.
    if ($DesktopConfig) { return @($DesktopConfig | Where-Object { Test-Path -LiteralPath $_ }) }
    $folders = @()
    $packages = Join-Path $env:LOCALAPPDATA 'Packages'
    if (Test-Path -LiteralPath $packages) {
        foreach ($package in Get-ChildItem -LiteralPath $packages -Directory -Filter 'Claude_*' -ErrorAction SilentlyContinue) {
            $folders += (Join-Path $package.FullName 'LocalCache\Roaming\Claude')
        }
    }
    $folders += (Join-Path $env:APPDATA 'Claude')
    $configs = @()
    $seen = @{}
    foreach ($folder in $folders) {
        $config = Join-Path $folder 'claude_desktop_config.json'
        if (-not (Test-Path -LiteralPath $config)) { continue }
        # inside the Store app's own view both folders are one file
        $item = Get-Item -LiteralPath $config
        $identity = '{0}|{1}' -f $item.Length, $item.LastWriteTimeUtc.Ticks
        if ($seen.ContainsKey($identity)) { continue }
        $seen[$identity] = $true
        $configs += $config
    }
    return $configs
}

function Get-ClaudeCode {
    $command = Get-Command claude -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    $candidate = Join-Path $env:USERPROFILE '.local\bin\claude.exe'
    if (Test-Path -LiteralPath $candidate) { return $candidate }
    return $null
}

function Get-ClaudeCodeConfig {
    if ($env:CLAUDE_CONFIG_DIR) { return (Join-Path $env:CLAUDE_CONFIG_DIR '.claude.json') }
    return (Join-Path $env:USERPROFILE '.claude.json')
}

function Get-OldEntries([string]$text, [string[]]$names) {
    # Those of the named entries in a config's text that are ours.
    $found = @()
    $block = Get-ServerBlock $text
    if (-not $block.Servers) { return $found }
    foreach ($name in $names) {
        $member = Find-Member $block.Servers $name
        if (-not $member) { continue }
        $existing = $script:Json.DeserializeObject($text.Substring($member.ValueStart, $member.ValueEnd - $member.ValueStart))
        if (Test-Ours $existing) { $found += $name }
    }
    return $found
}

function Get-EntryWords([string[]]$names) {
    if ($names.Count -eq 1) { return ($names[0] + ' entry') }
    return (($names -join ' and ') + ' entries')
}

function Remove-FromDesktop([string[]]$names) {
    foreach ($config in @(Get-DesktopConfigs)) {
        try {
            $read = Read-Text $config
            $old = @(Get-OldEntries $read.Text $names)
            if (-not $old.Count) { continue }
            if (-not (Need ('take the old ' + (Get-EntryWords $old) + ' out of Claude Desktop'))) { continue }
            Save-Config $config $read.Text (Remove-Servers $read.Text $old) $read.Bom $old
            $script:Changed = $true
            $script:RestartDesktop = $true
            Say ('  Taken out of Claude Desktop, where the plugin brings it now: ' + ($old -join ', ') + '.')
        } catch {
            Fail ("Claude Desktop's config was left untouched ($config): " + $_.Exception.Message)
        }
    }
}

function Remove-FromClaudeCode([string[]]$names) {
    # Claude Code changes its own config through its command line, so nothing is written behind its back.
    $claude = Get-ClaudeCode
    $config = Get-ClaudeCodeConfig
    if (-not $claude -or -not (Test-Path -LiteralPath $config)) { return }
    try {
        $old = @(Get-OldEntries (Read-Text $config).Text $names)
        if (-not $old.Count) { return }
        if (-not (Need ('take the old ' + (Get-EntryWords $old) + ' out of Claude Code'))) { return }
        foreach ($name in $old) {
            $code = Run-Tool $claude @('mcp', 'remove', '--scope', 'user', $name) $null
            if ($code -ne 0) { Fail "Claude Code would not take out `"$name`" (exit code $code). See $LogFile."; continue }
            $script:Changed = $true
            Say "  Taken out of Claude Code, where the plugin brings it now: $name."
        }
    } catch {
        Fail ("Claude Code's config was left untouched: " + $_.Exception.Message)
    }
}

function Remove-OldEntries([string[]]$names) {
    if (-not $SkipDesktop) { Remove-FromDesktop $names }
    if (-not $SkipClaudeCode) { Remove-FromClaudeCode $names }
}


# ------------------------------------------------------------------ uninstall
function Invoke-Uninstall {
    Say 'Removing the Alexandria connectors.'
    Remove-OldEntries @($RHINO_NAME, $COREL_NAME, $SQUARECOIL_NAME)
    if (Get-SquareCoilUser) {
        [void](& cmdkey.exe "/delete:$SQUARECOIL_TARGET")
        Write-Host '  Took the SquareCoil login out of Windows Credential Manager.'
    }
    if (Test-Path -LiteralPath $InstallHome) {
        try { Remove-Item -LiteralPath $InstallHome -Recurse -Force; Write-Host "  Deleted $InstallHome." }
        catch { Write-Host "  Could not delete all of $InstallHome. Quit Claude and Grok, and delete it by hand." }
    }
    Write-Host "The $RHINO_PACKAGE package stays in Rhino: uninstall it in Rhino's Package Manager if you want it gone."
    Write-Host "Alexandria's plugins stay in Claude and Grok, and say their server is missing until this is run again."
}


# ------------------------------------------------------------------ main
$CONNECTORS = [ordered]@{ rhino = 'Rhino'; coreldraw = 'CorelDRAW'; squarecoil = 'SquareCoil' }   # -Only's keys, in install order
$NAMES = @{ rhino = $RHINO_NAME; coreldraw = $COREL_NAME; squarecoil = $SQUARECOIL_NAME }       # each one's plugin, and old entry

function Get-Selected {
    # The connectors to work on: -Only's, comma-separated or not, else all of them.
    if (-not $Only) { return @($CONNECTORS.Keys) }
    $wanted = @($Only | ForEach-Object { $_ -split '[,\s]+' } | Where-Object { $_ } | ForEach-Object { $_.ToLowerInvariant() })
    foreach ($key in $wanted) { if (-not $CONNECTORS.Contains($key)) { throw "-Only: no connector called '$key' (rhino, coreldraw, squarecoil)" } }
    return @($CONNECTORS.Keys | Where-Object { $wanted -contains $_ })
}

function Invoke-Connector([string]$key) {
    # Installs (or, in -Check, looks over) one connector. Says what it is, for -Status.
    $script:Note = $null; $script:NoteKind = $null
    switch ($key) {
        'rhino' { [void](Install-Rhino); return "McNeel's $RHINO_PACKAGE" }
        'coreldraw' { [void](Install-Corel); return 'the CorelDRAW server' }
        'squarecoil' { [void](Install-SquareCoil); return ('signed in as ' + (Get-SquareCoilUser)) }
    }
}

$script:RestartDesktop = $false
$exit = 0
try {
    if ($Uninstall) {
        Invoke-Uninstall
    } else {
        Say 'Alexandria: the connectors for Claude and Grok'
        Say ''
        if (-not $Check -and -not (Test-Path -LiteralPath $InstallHome)) { New-Item -ItemType Directory -Force $InstallHome | Out-Null }
        $selected = @(Get-Selected)
        if ($Status) {
            # each connector told apart: its own to-do list, its program and any old Claude entry
            foreach ($key in $selected) {
                $script:Pending.Clear()
                $what = Invoke-Connector $key
                $kind = $script:NoteKind; $note = $script:Note
                Remove-OldEntries @($NAMES[$key])
                if ($script:Pending.Count) { $state = 'todo'; $what = ($script:Pending -join '; ') }
                elseif ($kind) { $state = $kind; $what = $note }
                elseif ($script:Failed.Count) { $state = 'failed'; $what = ($script:Failed -join '; '); $script:Failed.Clear() }
                else { $state = 'ok' }
                Write-Output ("{0}`t{1}`t{2}" -f $key, $state, $what)
            }
            $script:Pending.Clear()
        } else {
            foreach ($key in $selected) {
                Say $CONNECTORS[$key]
                [void](Invoke-Connector $key)
            }
            Remove-OldEntries @($selected | ForEach-Object { $NAMES[$_] })
        }
        Say ''
        if ($Status) {
        } elseif ($Check) {
            if ($script:Pending.Count) { Write-Output ($script:Pending -join '; '); $exit = 1 }
        } elseif ($script:Failed.Count) {
            Say 'Not everything went through:'
            foreach ($item in $script:Failed) { Say ('  ' + $item) }
            Say 'Run this again once that is sorted out.'
            $exit = 2
        } elseif ($script:Changed) {
            Say "Done. Claude and Grok start these through Alexandria's plugins."
            if ($script:RestartDesktop) { Say 'Quit Claude Desktop from its tray icon (right-click, Quit) and open it again.' }
        } else {
            Say 'Everything is already set up.'
        }
    }
} catch {
    $exit = 2
    Write-Host ('Stopped: ' + $_.Exception.Message)
    Log ('Stopped: ' + $_.Exception.Message + ' ' + $_.ScriptStackTrace)
}

if (-not $Check -and -not $NoPause) {
    Write-Host ''
    Write-Host 'Press any key to close.'
    try { [void][Console]::ReadKey($true) } catch { }
}
exit $exit
