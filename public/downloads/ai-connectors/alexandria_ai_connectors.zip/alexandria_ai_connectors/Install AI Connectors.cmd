@echo off
rem Alexandria: installs the AI connectors (MCP) for Rhino, CorelDRAW and SquareCoil on this PC.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
