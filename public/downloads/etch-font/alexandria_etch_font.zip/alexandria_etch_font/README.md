# Alexandria Etch

A single-line font for etching part labels, such as `A1` or `P1-1`, on fabricated items. Every letter is one line down
its middle, made only of straight lines and true arcs, so a laser or router passes once and the DXF stays clean.

It has A to Z, 0 to 9 and `- _ . , : ; / \ # + = * ( ) [ ] < > ' " ! ? % & °`. Lower case draws as capitals. The
zero is slashed and the one has a flag, so `O0` and `I1` can't be mixed up. See `specimen.pdf`.

## Files

| File | For |
| --- | --- |
| `alexandria_etch.json` | The strokes. The source the Rhino script reads. |
| `etch_text.py` | Rhino 8: draws text as open curves, as a command or as a module. |
| `alexandria_etch.svg` | An SVG font, for Inkscape's Hershey Text and laser software that reads SVG fonts. |
| `AlexandriaEtch.ttf` | A TrueType font, for typing and previews in other software. |
| `specimen.pdf` | The specimen sheet. Printed at 100% its sample labels are at real size. |

## Why a script and not just a font in Rhino

Rhino 8 treats a font as single-line only when its name is on a list built into Rhino (SLF-RHN, MecSoft, RhSS and
a few more); McNeel say so on their forum. Checked in Rhino 8.36: `SLF-RHN Architect` reports as an engraving font,
`Alexandria Etch` does not. So Rhino text set in our TTF would explode to closed outlines, each stroke traced twice.
A TrueType font can't hold an open path at all, which is why the TTF traces each stroke out and back.

`etch_text.py` skips Rhino's text and draws the strokes itself. That gives open curves every time, needs no font
installed on anyone's PC, and exports through the Fabrication Manager's DXF as plain lines and arcs.

## Use in Rhino

    _-RunPythonScript "<this folder>\etch_text.py"

It asks for the text, the capitals' height (it starts at 1/2" and remembers the last one) and the bottom left point,
then draws the text on the current layer as one group. Put it on `FAB::ETCH`, or select it as an Etch item's linework
in the Fabrication Manager, which takes curves as they are.

From another script:

    import etch_text
    curves = etch_text.curves("P1-1", plane, 0.5)   # nothing added to the model
    wide = etch_text.width("P1-1", 0.5)
